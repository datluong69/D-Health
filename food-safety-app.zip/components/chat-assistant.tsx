"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Send, Image, Paperclip, Smile, X } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useTranslation } from "@/hooks/use-translation"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
  isLoading?: boolean
  attachments?: Array<{
    type: "image" | "file"
    url: string
    name: string
  }>
}

export default function ChatAssistant() {
  const { t } = useTranslation()
  const [input, setInput] = useState("")
  const [conversation, setConversation] = useState<Message[]>([
    {
      id: "welcome",
      role: "assistant",
      content:
        "Xin chào! Tôi là trợ lý AI của D Healthy Life. Tôi có thể giúp bạn phân tích thực phẩm, đưa ra lời khuyên dinh dưỡng, hoặc trả lời các câu hỏi về sức khỏe và an toàn thực phẩm. Bạn cần hỗ trợ gì hôm nay?",
      timestamp: new Date(),
    },
  ])
  const [isTyping, setIsTyping] = useState(false)
  const [attachments, setAttachments] = useState<
    Array<{
      type: "image" | "file"
      url: string
      name: string
      file: File
    }>
  >([])
  const fileInputRef = useRef<HTMLInputElement>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Auto scroll to bottom when messages change
  useEffect(() => {
    scrollToBottom()
  }, [conversation])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() && attachments.length === 0) return

    // Create user message
    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date(),
      attachments: attachments.map((att) => ({
        type: att.type,
        url: att.url,
        name: att.name,
      })),
    }

    // Add user message to conversation
    setConversation((prev) => [...prev, userMessage])

    // Clear input and attachments
    setInput("")
    setAttachments([])

    // Show typing indicator
    setIsTyping(true)

    // Add temporary loading message
    const loadingId = Date.now().toString() + "-loading"
    setConversation((prev) => [
      ...prev,
      {
        id: loadingId,
        role: "assistant",
        content: "",
        timestamp: new Date(),
        isLoading: true,
      },
    ])

    // Generate AI response based on context
    setTimeout(() => {
      // Remove loading message
      setConversation((prev) => prev.filter((msg) => msg.id !== loadingId))

      // Generate response based on user input
      const response = generateResponse(input, userMessage.attachments)

      // Add AI response
      setConversation((prev) => [
        ...prev,
        {
          id: Date.now().toString(),
          role: "assistant",
          content: response,
          timestamp: new Date(),
        },
      ])

      setIsTyping(false)
    }, 1500)
  }

  const generateResponse = (userInput: string, attachments?: Message["attachments"]): string => {
    // Check if there's an image attachment
    const hasImage = attachments?.some((att) => att.type === "image")

    if (hasImage) {
      return "Tôi đã phân tích hình ảnh thực phẩm bạn gửi. Đây có vẻ là một món ăn giàu protein và chất xơ. Dựa trên hình ảnh, tôi ước tính món này có khoảng 350 calories, 20g protein, 12g chất béo và 30g carbohydrate. Tôi khuyên bạn nên kết hợp với rau xanh để cân bằng dinh dưỡng tốt hơn."
    }

    // Common food and nutrition questions
    if (userInput.toLowerCase().includes("calo") || userInput.toLowerCase().includes("calorie")) {
      return "Lượng calorie cần thiết hàng ngày phụ thuộc vào nhiều yếu tố như tuổi, giới tính, cân nặng và mức độ hoạt động. Trung bình, nam giới cần khoảng 2500 calories và nữ giới cần khoảng 2000 calories mỗi ngày. Bạn có thể sử dụng tính năng 'Hồ sơ cá nhân' trong ứng dụng để nhận được ước tính chính xác hơn dựa trên thông tin của bạn."
    }

    if (userInput.toLowerCase().includes("protein")) {
      return "Protein rất quan trọng cho việc xây dựng và phục hồi cơ bắp. Các nguồn protein tốt bao gồm thịt nạc, cá, trứng, đậu và các loại hạt. Lượng protein khuyến nghị hàng ngày là khoảng 0.8g/kg trọng lượng cơ thể. Đối với người tập thể thao, có thể cần nhiều hơn, từ 1.2-2.0g/kg."
    }

    if (userInput.toLowerCase().includes("vitamin") || userInput.toLowerCase().includes("khoáng chất")) {
      return "Vitamin và khoáng chất là các vi chất dinh dưỡng thiết yếu cho sức khỏe. Bạn nên ăn đa dạng các loại thực phẩm, đặc biệt là rau củ quả nhiều màu sắc để đảm bảo cung cấp đủ vitamin và khoáng chất. Một số vitamin quan trọng bao gồm vitamin A, C, D, E, K và các vitamin nhóm B. Khoáng chất thiết yếu bao gồm canxi, sắt, kẽm, magie và kali."
    }

    if (userInput.toLowerCase().includes("giảm cân") || userInput.toLowerCase().includes("giảm béo")) {
      return "Để giảm cân hiệu quả và bền vững, bạn nên kết hợp chế độ ăn uống lành mạnh với tập luyện đều đặn. Nên tạo thâm hụt calorie nhẹ (khoảng 500 calories/ngày), tăng cường protein, chất xơ, và uống đủ nước. Hạn chế thực phẩm chế biến sẵn, đồ ngọt và đồ chiên rán. Tôi có thể giúp bạn lập kế hoạch ăn uống phù hợp với mục tiêu giảm cân của bạn nếu bạn cung cấp thêm thông tin về chiều cao, cân nặng và lối sống."
    }

    if (userInput.toLowerCase().includes("tăng cân") || userInput.toLowerCase().includes("tăng cơ")) {
      return "Để tăng cân và phát triển cơ bắp, bạn cần tiêu thụ nhiều calories hơn mức cơ thể đốt cháy (thặng dư calories) và tăng cường protein. Nên ăn 5-6 bữa nhỏ mỗi ngày, tập trung vào thực phẩm giàu dinh dưỡng như thịt nạc, cá, trứng, các loại hạt, sữa và sản phẩm từ sữa, ngũ cốc nguyên hạt và trái cây. Kết hợp với tập luyện sức mạnh để kích thích phát triển cơ bắp."
    }

    if (userInput.toLowerCase().includes("thực phẩm hữu cơ") || userInput.toLowerCase().includes("organic")) {
      return "Thực phẩm hữu cơ được sản xuất mà không sử dụng phân bón hóa học, thuốc trừ sâu tổng hợp, hormone tăng trưởng, kháng sinh, hoặc sinh vật biến đổi gen (GMO). Chúng có thể chứa nhiều chất chống oxy hóa hơn và giảm tiếp xúc với dư lượng thuốc trừ sâu. Tuy nhiên, về giá trị dinh dưỡng cơ bản, nghiên cứu chưa chỉ ra sự khác biệt đáng kể giữa thực phẩm hữu cơ và thông thường. Nếu ngân sách có hạn, bạn có thể ưu tiên mua hữu cơ đối với những loại rau củ quả thường có nhiều dư lượng thuốc trừ sâu nhất."
    }

    if (
      userInput.toLowerCase().includes("chào") ||
      userInput.toLowerCase().includes("xin chào") ||
      userInput.toLowerCase().includes("hi") ||
      userInput.toLowerCase().includes("hello")
    ) {
      return "Xin chào! Rất vui được trò chuyện với bạn. Tôi là trợ lý AI của D Healthy Life, luôn sẵn sàng giúp bạn với các vấn đề về dinh dưỡng, an toàn thực phẩm và sức khỏe. Bạn cần tôi tư vấn về vấn đề gì hôm nay?"
    }

    if (userInput.toLowerCase().includes("cảm ơn") || userInput.toLowerCase().includes("thank")) {
      return "Không có gì! Tôi rất vui khi được giúp đỡ bạn. Nếu bạn có bất kỳ câu hỏi nào khác về dinh dưỡng hoặc sức khỏe, đừng ngần ngại hỏi tôi nhé. Chúc bạn có một ngày tốt lành và đầy năng lượng!"
    }

    // Default response if no specific pattern is matched
    return "Cảm ơn bạn đã chia sẻ. Tôi có thể giúp bạn phân tích chi tiết hơn về thực phẩm hoặc chế độ ăn uống nếu bạn cung cấp thêm thông tin. Bạn có thể hỏi tôi về giá trị dinh dưỡng của thực phẩm cụ thể, lời khuyên về chế độ ăn uống, hoặc cách đảm bảo an toàn thực phẩm."
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files || files.length === 0) return

    // Process each file
    Array.from(files).forEach((file) => {
      // Create URL for preview
      const url = URL.createObjectURL(file)

      // Determine file type
      const type = file.type.startsWith("image/") ? "image" : "file"

      // Add to attachments
      setAttachments((prev) => [
        ...prev,
        {
          type,
          url,
          name: file.name,
          file,
        },
      ])
    })

    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const removeAttachment = (index: number) => {
    setAttachments((prev) => prev.filter((_, i) => i !== index))
  }

  return (
    <Card className="flex flex-col h-[600px]">
      <CardContent className="flex flex-col h-full p-0">
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {conversation.map((message) => (
            <div key={message.id} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
              <div className="flex items-start max-w-[80%]">
                {message.role === "assistant" && (
                  <Avatar className="mr-2 mt-1">
                    <AvatarImage src="/placeholder.svg?height=40&width=40" />
                    <AvatarFallback className="bg-green-600 text-white">AI</AvatarFallback>
                  </Avatar>
                )}

                <div
                  className={`rounded-lg p-3 ${
                    message.role === "user" ? "bg-green-600 text-white" : "bg-gray-100 text-gray-800"
                  }`}
                >
                  {message.isLoading ? (
                    <div className="flex space-x-1 items-center h-6">
                      <div
                        className="w-2 h-2 rounded-full bg-gray-400 animate-bounce"
                        style={{ animationDelay: "0ms" }}
                      ></div>
                      <div
                        className="w-2 h-2 rounded-full bg-gray-400 animate-bounce"
                        style={{ animationDelay: "150ms" }}
                      ></div>
                      <div
                        className="w-2 h-2 rounded-full bg-gray-400 animate-bounce"
                        style={{ animationDelay: "300ms" }}
                      ></div>
                    </div>
                  ) : (
                    <>
                      <p className="whitespace-pre-line">{message.content}</p>

                      {/* Display attachments if any */}
                      {message.attachments && message.attachments.length > 0 && (
                        <div className="mt-2 space-y-2">
                          {message.attachments.map((attachment, index) => (
                            <div key={index}>
                              {attachment.type === "image" && (
                                <img
                                  src={attachment.url || "/placeholder.svg"}
                                  alt={attachment.name}
                                  className="max-w-full rounded-md max-h-40 object-contain"
                                />
                              )}
                              {attachment.type === "file" && (
                                <div className="flex items-center p-2 bg-gray-200 rounded-md">
                                  <Paperclip className="h-4 w-4 mr-2" />
                                  <span className="text-sm truncate">{attachment.name}</span>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      )}

                      <p className="text-xs opacity-70 mt-1">
                        {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </p>
                    </>
                  )}
                </div>

                {message.role === "user" && (
                  <Avatar className="ml-2 mt-1">
                    <AvatarImage src="/placeholder.svg?height=40&width=40" />
                    <AvatarFallback className="bg-sky-500 text-white">U</AvatarFallback>
                  </Avatar>
                )}
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        {/* Attachments preview */}
        {attachments.length > 0 && (
          <div className="px-4 py-2 border-t flex gap-2 overflow-x-auto">
            {attachments.map((attachment, index) => (
              <div key={index} className="relative">
                {attachment.type === "image" ? (
                  <div className="relative w-16 h-16">
                    <img
                      src={attachment.url || "/placeholder.svg"}
                      alt={attachment.name}
                      className="w-16 h-16 object-cover rounded-md"
                    />
                    <button
                      onClick={() => removeAttachment(index)}
                      className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                ) : (
                  <div className="relative flex items-center p-2 bg-gray-200 rounded-md">
                    <Paperclip className="h-4 w-4 mr-2" />
                    <span className="text-sm truncate max-w-[100px]">{attachment.name}</span>
                    <button onClick={() => removeAttachment(index)} className="ml-2 text-red-500">
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        <form onSubmit={handleSend} className="p-4 border-t mt-auto">
          <div className="flex space-x-2">
            <div className="relative">
              <Button type="button" size="icon" variant="ghost" onClick={() => fileInputRef.current?.click()}>
                <Image className="h-5 w-5 text-gray-500" />
              </Button>
              <input type="file" ref={fileInputRef} onChange={handleFileUpload} accept="image/*" className="hidden" />
            </div>
            <Button type="button" size="icon" variant="ghost">
              <Paperclip className="h-5 w-5 text-gray-500" />
            </Button>
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Nhập tin nhắn của bạn..."
              className="flex-1"
            />
            <Button type="button" size="icon" variant="ghost">
              <Smile className="h-5 w-5 text-gray-500" />
            </Button>
            <Button type="submit" size="icon" className="bg-green-600 hover:bg-green-700">
              <Send className="h-5 w-5" />
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}

