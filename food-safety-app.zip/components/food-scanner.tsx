"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Camera, Check, X, AlertTriangle, Loader2, Upload } from "lucide-react"
import { Progress } from "@/components/ui/progress"
import CameraCapture from "./camera-capture"
import { useTranslation } from "@/hooks/use-translation"

export default function FoodScanner() {
  const { t } = useTranslation()
  const [scanning, setScanning] = useState(false)
  const [scanned, setScanned] = useState(false)
  const [progress, setProgress] = useState(0)
  const [results, setResults] = useState<ScanResult | null>(null)
  const [showCamera, setShowCamera] = useState(false)
  const [capturedImage, setCapturedImage] = useState<string | null>(null)

  const handleScan = () => {
    setScanning(true)
    setProgress(0)
    setScanned(false)
    setResults(null)

    // Simulate scanning progress
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setScanning(false)
          setScanned(true)
          // Simulate scan results
          setResults({
            name: "Táo Fuji Organic",
            safe: true,
            nutrition: {
              calories: 52,
              protein: 0.3,
              fat: 0.2,
              carbs: 14,
              fiber: 2.4,
              sugar: 10.4,
            },
            warnings: [],
            recommendations: [
              t("nutrition.recommendation.vitaminC"),
              t("nutrition.recommendation.fiber"),
              t("nutrition.recommendation.eatWithSkin"),
            ],
          })
          return 100
        }
        return prev + 5
      })
    }, 150)
  }

  const resetScan = () => {
    setScanned(false)
    setResults(null)
    setCapturedImage(null)
  }

  const handleCameraCapture = (imageBlob: Blob) => {
    const imageUrl = URL.createObjectURL(imageBlob)
    setCapturedImage(imageUrl)
    setShowCamera(false)
    handleScan()
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const imageUrl = URL.createObjectURL(file)
      setCapturedImage(imageUrl)
      handleScan()
    }
  }

  return (
    <Card className="w-full overflow-hidden">
      <CardContent className="p-0">
        <div className="relative aspect-video bg-gray-100 flex items-center justify-center">
          {showCamera ? (
            <CameraCapture onCapture={handleCameraCapture} onCancel={() => setShowCamera(false)} />
          ) : !scanning && !scanned ? (
            <div className="text-center p-6">
              {capturedImage ? (
                <img
                  src={capturedImage || "/placeholder.svg"}
                  alt="Food to analyze"
                  className="w-full h-64 object-contain mb-4"
                />
              ) : (
                <Camera className="h-12 w-12 mx-auto mb-4 text-gray-400" />
              )}
              <p className="text-gray-500 mb-4">{t("scanner.instruction")}</p>
              <div className="flex flex-col sm:flex-row justify-center gap-2">
                <Button onClick={() => setShowCamera(true)} className="bg-green-600 hover:bg-green-700">
                  <Camera className="mr-2 h-4 w-4" />
                  {t("scanner.openCamera")}
                </Button>
                <div className="relative">
                  <Button variant="outline" className="w-full">
                    <Upload className="mr-2 h-4 w-4" />
                    {t("scanner.uploadPhoto")}
                  </Button>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="absolute inset-0 opacity-0 cursor-pointer"
                  />
                </div>
                {capturedImage && (
                  <Button onClick={handleScan} className="bg-green-600 hover:bg-green-700">
                    {t("scanner.analyze")}
                  </Button>
                )}
              </div>
            </div>
          ) : scanning ? (
            <div className="text-center p-6 w-full">
              {capturedImage && (
                <img
                  src={capturedImage || "/placeholder.svg"}
                  alt="Food being analyzed"
                  className="w-full h-64 object-contain mb-4 opacity-50"
                />
              )}
              <Loader2 className="h-12 w-12 mx-auto mb-4 text-green-600 animate-spin" />
              <p className="text-gray-700 mb-4">{t("scanner.analyzing")}</p>
              <Progress value={progress} className="w-full h-2" />
              <p className="text-sm text-gray-500 mt-2">{t("scanner.pleaseWait")}</p>
            </div>
          ) : (
            <div className="p-6 w-full">
              {results && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xl font-bold">{results.name}</h3>
                    {results.safe ? (
                      <Badge variant="success">
                        <Check className="h-4 w-4 mr-1" />
                        {t("scanner.safe")}
                      </Badge>
                    ) : (
                      <Badge variant="destructive">
                        <AlertTriangle className="h-4 w-4 mr-1" />
                        {t("scanner.warning")}
                      </Badge>
                    )}
                  </div>

                  <div>
                    <h4 className="font-medium mb-2">{t("nutrition.info")}</h4>
                    <div className="grid grid-cols-3 gap-2">
                      <NutritionItem label={t("nutrition.calories")} value={`${results.nutrition.calories} kcal`} />
                      <NutritionItem label={t("nutrition.protein")} value={`${results.nutrition.protein}g`} />
                      <NutritionItem label={t("nutrition.fat")} value={`${results.nutrition.fat}g`} />
                      <NutritionItem label={t("nutrition.carbs")} value={`${results.nutrition.carbs}g`} />
                      <NutritionItem label={t("nutrition.fiber")} value={`${results.nutrition.fiber}g`} />
                      <NutritionItem label={t("nutrition.sugar")} value={`${results.nutrition.sugar}g`} />
                    </div>
                  </div>

                  {results.warnings.length > 0 && (
                    <div>
                      <h4 className="font-medium mb-2 text-red-600">{t("scanner.warnings")}</h4>
                      <ul className="list-disc list-inside text-sm space-y-1">
                        {results.warnings.map((warning, index) => (
                          <li key={index} className="text-red-600">
                            {warning}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  <div>
                    <h4 className="font-medium mb-2 text-green-600">{t("scanner.recommendations")}</h4>
                    <ul className="list-disc list-inside text-sm space-y-1">
                      {results.recommendations.map((rec, index) => (
                        <li key={index} className="text-green-600">
                          {rec}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="flex justify-end space-x-2 pt-2">
                    <Button variant="outline" onClick={resetScan}>
                      <X className="mr-2 h-4 w-4" />
                      {t("scanner.scanAgain")}
                    </Button>
                    <Button className="bg-green-600 hover:bg-green-700">{t("scanner.viewDetails")}</Button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

function NutritionItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-gray-50 p-2 rounded text-center">
      <p className="text-xs text-gray-500">{label}</p>
      <p className="font-medium">{value}</p>
    </div>
  )
}

function Badge({
  children,
  variant = "default",
}: {
  children: React.ReactNode
  variant?: "default" | "success" | "destructive"
}) {
  const variantClasses = {
    default: "bg-gray-100 text-gray-800",
    success: "bg-green-100 text-green-800",
    destructive: "bg-red-100 text-red-800",
  }

  return (
    <span
      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${variantClasses[variant]}`}
    >
      {children}
    </span>
  )
}

interface ScanResult {
  name: string
  safe: boolean
  nutrition: {
    calories: number
    protein: number
    fat: number
    carbs: number
    fiber: number
    sugar: number
  }
  warnings: string[]
  recommendations: string[]
}

