"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Bell, Camera, Home, Menu, MessageSquare, Settings } from "lucide-react"
import { Badge } from "./ui/badge"
import Logo from "./logo"
import LanguageSelector from "./language-selector"
import { useTranslation } from "@/hooks/use-translation"

export default function Navigation() {
  const { t } = useTranslation()
  const pathname = usePathname()
  const [isOpen, setIsOpen] = useState(false)

  const routes = [
    {
      name: "Trang Chủ",
      path: "/",
      icon: <Home className="h-5 w-5" />,
    },
    {
      name: "Quét Thực Phẩm",
      path: "/scan",
      icon: <Camera className="h-5 w-5" />,
    },
    {
      name: "Thông Báo",
      path: "/notifications",
      icon: <Bell className="h-5 w-5" />,
      badge: 3,
    },
    {
      name: "Trò Chuyện",
      path: "/chat",
      icon: <MessageSquare className="h-5 w-5" />,
    },
  ]

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white/80 backdrop-blur-sm">
      <div className="container flex h-16 items-center justify-between px-4">
        <div className="flex items-center">
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild className="lg:hidden">
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-64">
              <div className="flex flex-col space-y-4 py-4">
                <div className="px-3 py-2">
                  <Logo size="large" />
                  <p className="text-sm text-gray-500 mt-2">Ứng dụng phân tích thực phẩm thông minh</p>
                </div>
                <div className="px-3 py-2">
                  <div className="flex items-center space-x-3">
                    <Avatar>
                      <AvatarImage src="/placeholder.svg?height=32&width=32" />
                      <AvatarFallback className="bg-sky-500 text-white">UN</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-sm font-medium">Người Dùng</p>
                      <p className="text-xs text-gray-500">user@example.com</p>
                    </div>
                  </div>
                </div>
                <nav className="space-y-1 px-3">
                  {routes.map((route) => (
                    <Link
                      key={route.path}
                      href={route.path}
                      onClick={() => setIsOpen(false)}
                      className={`flex items-center justify-between rounded-md px-3 py-2 text-sm font-medium ${
                        pathname === route.path ? "bg-green-100 text-green-600" : "text-gray-700 hover:bg-gray-100"
                      }`}
                    >
                      <div className="flex items-center">
                        {route.icon}
                        <span className="ml-3">{route.name}</span>
                      </div>
                      {route.badge && <Badge className="bg-green-600">{route.badge}</Badge>}
                    </Link>
                  ))}
                </nav>
              </div>
            </SheetContent>
          </Sheet>
          <Link href="/" className="flex items-center space-x-2">
            <Logo />
          </Link>
        </div>
        <nav className="hidden lg:flex items-center space-x-4">
          {routes.map((route) => (
            <Link
              key={route.path}
              href={route.path}
              className={`flex items-center px-3 py-2 text-sm font-medium rounded-md ${
                pathname === route.path ? "bg-green-100 text-green-600" : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              {route.icon}
              <span className="ml-2">{route.name}</span>
              {route.badge && <Badge className="ml-1 bg-green-600">{route.badge}</Badge>}
            </Link>
          ))}
        </nav>
        <div className="flex items-center space-x-2">
          <LanguageSelector />
          <Button variant="ghost" size="icon" asChild>
            <Link href="/settings">
              <Settings className="h-5 w-5" />
              <span className="sr-only">Settings</span>
            </Link>
          </Button>
          <Button variant="ghost" size="icon" asChild>
            <Link href="/profile">
              <Avatar>
                <AvatarImage src="/placeholder.svg?height=32&width=32" />
                <AvatarFallback className="bg-sky-500 text-white">UN</AvatarFallback>
              </Avatar>
              <span className="sr-only">Profile</span>
            </Link>
          </Button>
        </div>
      </div>
    </header>
  )
}

