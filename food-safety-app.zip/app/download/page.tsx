import Navigation from "@/components/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Download, Smartphone, Laptop, Globe, CheckCircle2, AlertTriangle } from "lucide-react"
import Link from "next/link"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function DownloadPage() {
  return (
    <main className="flex min-h-screen flex-col bg-gradient-to-b from-green-50 to-sky-50">
      <Navigation />

      <div className="container px-4 py-6 mx-auto">
        <div className="flex items-center mb-6">
          <Download className="h-8 w-8 text-green-600 mr-3" />
          <h1 className="text-3xl font-bold text-green-600">Tải Ứng Dụng D Healthy Life</h1>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Chọn Phiên Bản Phù Hợp</CardTitle>
                <CardDescription>D Healthy Life có sẵn trên nhiều nền tảng để đáp ứng nhu cầu của bạn</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="mobile">
                  <TabsList className="grid w-full grid-cols-3 mb-6">
                    <TabsTrigger value="mobile">
                      <div className="flex items-center">
                        <Smartphone className="h-4 w-4 mr-2" />
                        Ứng dụng di động
                      </div>
                    </TabsTrigger>
                    <TabsTrigger value="desktop">
                      <div className="flex items-center">
                        <Laptop className="h-4 w-4 mr-2" />
                        Ứng dụng máy tính
                      </div>
                    </TabsTrigger>
                    <TabsTrigger value="web">
                      <div className="flex items-center">
                        <Globe className="h-4 w-4 mr-2" />
                        Phiên bản web
                      </div>
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="mobile">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <div className="flex items-center space-x-2">
                          <div className="w-12 h-12 rounded-xl bg-black flex items-center justify-center">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="24"
                              height="24"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="white"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            >
                              <path d="M12 19a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"></path>
                              <path d="M16 6H8a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2z"></path>
                              <path d="M12 6v2"></path>
                            </svg>
                          </div>
                          <div>
                            <h3 className="font-medium">iOS</h3>
                            <p className="text-sm text-gray-500">iPhone & iPad</p>
                          </div>
                        </div>
                        <p className="text-sm">
                          Tải ứng dụng D Healthy Life cho thiết bị iOS để có trải nghiệm tốt nhất với các tính năng đầy
                          đủ.
                        </p>
                        <div className="flex space-x-2">
                          <Button className="bg-black text-white hover:bg-gray-800" asChild>
                            <a href="#" download>
                              <Download className="mr-2 h-4 w-4" />
                              Tải cho iOS
                            </a>
                          </Button>
                          <Button variant="outline">Quét mã QR</Button>
                        </div>
                        <div className="text-xs text-gray-500">Yêu cầu iOS 14.0 trở lên</div>
                      </div>

                      <div className="space-y-4">
                        <div className="flex items-center space-x-2">
                          <div className="w-12 h-12 rounded-xl bg-green-600 flex items-center justify-center">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="24"
                              height="24"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="white"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            >
                              <path d="M5 17H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-1"></path>
                              <polygon points="12 15 17 21 7 21 12 15"></polygon>
                            </svg>
                          </div>
                          <div>
                            <h3 className="font-medium">Android</h3>
                            <p className="text-sm text-gray-500">Điện thoại & Máy tính bảng</p>
                          </div>
                        </div>
                        <p className="text-sm">
                          Tải ứng dụng D Healthy Life cho thiết bị Android với đầy đủ tính năng và tối ưu hóa hiệu suất.
                        </p>
                        <div className="flex space-x-2">
                          <Button className="bg-green-600 hover:bg-green-700" asChild>
                            <a href="#" download>
                              <Download className="mr-2 h-4 w-4" />
                              Tải cho Android
                            </a>
                          </Button>
                          <Button variant="outline">Quét mã QR</Button>
                        </div>
                        <div className="text-xs text-gray-500">Yêu cầu Android 8.0 trở lên</div>
                      </div>
                    </div>

                    <div className="mt-6 p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                      <div className="flex">
                        <AlertTriangle className="h-5 w-5 text-yellow-600 mr-2 flex-shrink-0" />
                        <div>
                          <h3 className="font-medium text-yellow-800">Lưu ý khi cài đặt</h3>
                          <p className="text-sm text-yellow-700 mt-1">
                            Để cài đặt ứng dụng từ nguồn không phải App Store hoặc Google Play, bạn cần cho phép cài đặt
                            từ nguồn không xác định trong cài đặt thiết bị. Chúng tôi đảm bảo ứng dụng an toàn và không
                            chứa mã độc.
                          </p>
                        </div>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="desktop">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="space-y-4">
                        <div className="flex items-center space-x-2">
                          <div className="w-12 h-12 rounded-xl bg-blue-600 flex items-center justify-center">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="24"
                              height="24"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="white"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            >
                              <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                              <line x1="8" y1="21" x2="16" y2="21"></line>
                              <line x1="12" y1="17" x2="12" y2="21"></line>
                            </svg>
                          </div>
                          <div>
                            <h3 className="font-medium">Windows</h3>
                            <p className="text-sm text-gray-500">Windows 10/11</p>
                          </div>
                        </div>
                        <Button className="w-full bg-blue-600 hover:bg-blue-700" asChild>
                          <a href="#" download>
                            <Download className="mr-2 h-4 w-4" />
                            Tải cho Windows
                          </a>
                        </Button>
                      </div>

                      <div className="space-y-4">
                        <div className="flex items-center space-x-2">
                          <div className="w-12 h-12 rounded-xl bg-gray-800 flex items-center justify-center">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="24"
                              height="24"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="white"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            >
                              <path d="M12 3c.132 0 .263 0 .393 0a7.5 7.5 0 0 0 7.92 12.446a9 9 0 1 1 -8.313 -12.454z"></path>
                            </svg>
                          </div>
                          <div>
                            <h3 className="font-medium">macOS</h3>
                            <p className="text-sm text-gray-500">macOS 11+</p>
                          </div>
                        </div>
                        <Button className="w-full bg-gray-800 hover:bg-gray-700" asChild>
                          <a href="#" download>
                            <Download className="mr-2 h-4 w-4" />
                            Tải cho macOS
                          </a>
                        </Button>
                      </div>

                      <div className="space-y-4">
                        <div className="flex items-center space-x-2">
                          <div className="w-12 h-12 rounded-xl bg-orange-600 flex items-center justify-center">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="24"
                              height="24"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="white"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            >
                              <line x1="4" y1="9" x2="20" y2="9"></line>
                              <line x1="4" y1="15" x2="20" y2="15"></line>
                              <line x1="10" y1="3" x2="8" y2="21"></line>
                              <line x1="16" y1="3" x2="14" y2="21"></line>
                            </svg>
                          </div>
                          <div>
                            <h3 className="font-medium">Linux</h3>
                            <p className="text-sm text-gray-500">Ubuntu, Debian, Fedora</p>
                          </div>
                        </div>
                        <Button className="w-full bg-orange-600 hover:bg-orange-700" asChild>
                          <a href="#" download>
                            <Download className="mr-2 h-4 w-4" />
                            Tải cho Linux
                          </a>
                        </Button>
                      </div>
                    </div>

                    <Alert className="mt-6">
                      <CheckCircle2 className="h-4 w-4 text-green-600" />
                      <AlertTitle>Đồng bộ hóa dữ liệu</AlertTitle>
                      <AlertDescription>
                        Ứng dụng máy tính có thể đồng bộ hóa dữ liệu với ứng dụng di động thông qua tài khoản D Healthy
                        Life của bạn.
                      </AlertDescription>
                    </Alert>
                  </TabsContent>

                  <TabsContent value="web">
                    <div className="space-y-4">
                      <p>
                        Phiên bản web của D Healthy Life có thể được cài đặt như một Progressive Web App (PWA) trên hầu
                        hết các trình duyệt hiện đại.
                      </p>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                        <div className="border rounded-lg p-4">
                          <h3 className="font-medium mb-2">Cài đặt trên Chrome/Edge</h3>
                          <ol className="list-decimal list-inside text-sm space-y-2">
                            <li>Mở trang web D Healthy Life</li>
                            <li>Nhấp vào biểu tượng cài đặt (dấu + trong thanh địa chỉ)</li>
                            <li>Chọn "Cài đặt" hoặc "Thêm vào màn hình chính"</li>
                            <li>Làm theo hướng dẫn trên màn hình</li>
                          </ol>
                        </div>

                        <div className="border rounded-lg p-4">
                          <h3 className="font-medium mb-2">Cài đặt trên Safari (iOS)</h3>
                          <ol className="list-decimal list-inside text-sm space-y-2">
                            <li>Mở trang web D Healthy Life trong Safari</li>
                            <li>Nhấn vào biểu tượng Chia sẻ (hình mũi tên lên)</li>
                            <li>Chọn "Thêm vào màn hình chính"</li>
                            <li>Nhấn "Thêm" để xác nhận</li>
                          </ol>
                        </div>
                      </div>

                      <div className="flex justify-center mt-6">
                        <Button className="bg-green-600 hover:bg-green-700" asChild>
                          <Link href="/">
                            <Globe className="mr-2 h-4 w-4" />
                            Mở phiên bản web
                          </Link>
                        </Button>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Hướng Dẫn Cài Đặt</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium mb-2">Cài đặt trên iOS</h3>
                    <ol className="list-decimal list-inside space-y-2">
                      <li>Tải xuống tệp .ipa từ nút "Tải cho iOS" ở trên</li>
                      <li>Mở ứng dụng AltStore hoặc Sideloadly trên máy tính của bạn</li>
                      <li>Kết nối iPhone/iPad với máy tính</li>
                      <li>Kéo tệp .ipa vào AltStore hoặc Sideloadly</li>
                      <li>Làm theo hướng dẫn để cài đặt ứng dụng</li>
                      <li>Tin cậy nhà phát triển trong Cài đặt &gt; Cài đặt chung &gt; Quản lý thiết bị</li>
                    </ol>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">Cài đặt trên Android</h3>
                    <ol className="list-decimal list-inside space-y-2">
                      <li>Tải xuống tệp .apk từ nút "Tải cho Android" ở trên</li>
                      <li>Mở tệp .apk trên thiết bị Android của bạn</li>
                      <li>Nếu được nhắc, hãy cho phép cài đặt từ nguồn không xác định</li>
                      <li>Làm theo hướng dẫn trên màn hình để hoàn tất cài đặt</li>
                      <li>Mở ứng dụng và đăng nhập hoặc tạo tài khoản mới</li>
                    </ol>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">Cài đặt trên máy tính</h3>
                    <ol className="list-decimal list-inside space-y-2">
                      <li>Tải xuống tệp cài đặt phù hợp với hệ điều hành của bạn</li>
                      <li>Mở tệp cài đặt và làm theo hướng dẫn trên màn hình</li>
                      <li>Khởi động ứng dụng sau khi cài đặt hoàn tất</li>
                      <li>Đăng nhập bằng tài khoản hiện có hoặc tạo tài khoản mới</li>
                    </ol>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Yêu Cầu Hệ Thống</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm font-medium">iOS</h3>
                    <ul className="list-disc list-inside text-sm space-y-1 mt-1">
                      <li>iOS 14.0 trở lên</li>
                      <li>iPhone 6s trở lên, iPad Air 2 trở lên</li>
                      <li>Tối thiểu 200MB dung lượng trống</li>
                      <li>Kết nối internet để đồng bộ dữ liệu</li>
                    </ul>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium">Android</h3>
                    <ul className="list-disc list-inside text-sm space-y-1 mt-1">
                      <li>Android 8.0 (Oreo) trở lên</li>
                      <li>RAM tối thiểu 2GB</li>
                      <li>Tối thiểu 150MB dung lượng trống</li>
                      <li>Kết nối internet để đồng bộ dữ liệu</li>
                    </ul>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium">Windows</h3>
                    <ul className="list-disc list-inside text-sm space-y-1 mt-1">
                      <li>Windows 10 (64-bit) trở lên</li>
                      <li>RAM tối thiểu 4GB</li>
                      <li>Tối thiểu 500MB dung lượng trống</li>
                      <li>Bộ xử lý Intel Core i3 hoặc tương đương</li>
                    </ul>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium">macOS</h3>
                    <ul className="list-disc list-inside text-sm space-y-1 mt-1">
                      <li>macOS 11 (Big Sur) trở lên</li>
                      <li>RAM tối thiểu 4GB</li>
                      <li>Tối thiểu 500MB dung lượng trống</li>
                      <li>Bộ xử lý Intel hoặc Apple Silicon</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Tính Năng Nổi Bật</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-start">
                    <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 mr-2" />
                    <p className="text-sm">Phân tích thực phẩm ngoại tuyến</p>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 mr-2" />
                    <p className="text-sm">Đồng bộ hóa dữ liệu giữa các thiết bị</p>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 mr-2" />
                    <p className="text-sm">Thông báo đẩy về cảnh báo an toàn thực phẩm</p>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 mr-2" />
                    <p className="text-sm">Quét mã QR để xác minh nguồn gốc thực phẩm</p>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 mr-2" />
                    <p className="text-sm">Tích hợp với các thiết bị đeo thông minh</p>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 mr-2" />
                    <p className="text-sm">Lập kế hoạch bữa ăn và mua sắm thông minh</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Hỗ Trợ</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <p className="text-sm">
                    Nếu bạn gặp vấn đề khi tải xuống hoặc cài đặt ứng dụng, vui lòng liên hệ với đội ngũ hỗ trợ của
                    chúng tôi.
                  </p>
                  <Button variant="outline" className="w-full">
                    Liên hệ hỗ trợ kỹ thuật
                  </Button>
                  <div className="text-xs text-gray-500 text-center">Thời gian phản hồi: trong vòng 24 giờ</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </main>
  )
}

