"use client"

import { useState, useEffect, useRef } from "react"

interface UseCameraOptions {
  onPhotoCapture?: (photoBlob: Blob) => void
}

export function useCamera(options?: UseCameraOptions) {
  const videoRef = useRef<HTMLVideoElement | null>(null)
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const [isActive, setIsActive] = useState(false)
  const [hasPermission, setHasPermission] = useState<boolean | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [facingMode, setFacingMode] = useState<"user" | "environment">("environment")

  const startCamera = async () => {
    try {
      const constraints = {
        video: {
          facingMode: facingMode,
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
      }

      const stream = await navigator.mediaDevices.getUserMedia(constraints)

      if (videoRef.current) {
        videoRef.current.srcObject = stream
        setIsActive(true)
        setHasPermission(true)
        setError(null)
      }
    } catch (err) {
      console.error("Error accessing camera:", err)
      setError("Không thể truy cập camera. Vui lòng kiểm tra quyền truy cập.")
      setHasPermission(false)
      setIsActive(false)
    }
  }

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks()
      tracks.forEach((track) => track.stop())
      videoRef.current.srcObject = null
      setIsActive(false)
    }
  }

  const switchCamera = () => {
    stopCamera()
    setFacingMode((prev) => (prev === "user" ? "environment" : "user"))
  }

  const takePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return null

    const video = videoRef.current
    const canvas = canvasRef.current
    const context = canvas.getContext("2d")

    if (!context) return null

    // Set canvas dimensions to match video
    canvas.width = video.videoWidth
    canvas.height = video.videoHeight

    // Draw the current video frame on the canvas
    context.drawImage(video, 0, 0, canvas.width, canvas.height)

    // Convert canvas to blob
    canvas.toBlob(
      (blob) => {
        if (blob && options?.onPhotoCapture) {
          options.onPhotoCapture(blob)
        }
      },
      "image/jpeg",
      0.95,
    )
  }

  // Clean up on unmount
  useEffect(() => {
    return () => {
      stopCamera()
    }
  }, [])

  // Restart camera when facing mode changes
  useEffect(() => {
    if (isActive) {
      startCamera()
    }
  }, [facingMode])

  return {
    videoRef,
    canvasRef,
    isActive,
    hasPermission,
    error,
    facingMode,
    startCamera,
    stopCamera,
    switchCamera,
    takePhoto,
  }
}

