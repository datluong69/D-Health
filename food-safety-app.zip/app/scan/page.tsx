import Navigation from "@/components/navigation"
import FoodScanner from "@/components/food-scanner"

export default function ScanPage() {
  return (
    <main className="flex min-h-screen flex-col bg-gradient-to-b from-green-50 to-sky-50">
      <Navigation />

      <div className="container px-4 py-6 mx-auto">
        <h1 className="text-3xl font-bold text-green-600 mb-6">Quét Thực Phẩm</h1>

        <div className="max-w-2xl mx-auto">
          <FoodScanner />

          <div className="mt-6 bg-white p-6 rounded-lg shadow-sm">
            <h2 className="text-xl font-semibold mb-4">Hướng dẫn sử dụng</h2>
            <ul className="list-disc list-inside space-y-2 text-gray-700">
              <li>Chụp ảnh thực phẩm hoặc tải ảnh lên từ thiết bị của bạn</li>
              <li>Đảm bảo ảnh rõ nét và đủ ánh sáng để AI phân tích chính xác</li>
              <li>Đặt thực phẩm trên nền trơn, tránh các vật thể khác trong khung hình</li>
              <li>Bạn cũng có thể quét mã QR trên bao bì để xem thông tin chi tiết</li>
              <li>Sau khi phân tích, hệ thống sẽ hiển thị thông tin dinh dưỡng và các khuyến nghị</li>
              <li>Lưu kết quả phân tích để theo dõi chế độ ăn uống của bạn</li>
            </ul>
          </div>
        </div>
      </div>
    </main>
  )
}

