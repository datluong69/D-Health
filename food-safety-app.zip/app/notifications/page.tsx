import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Navigation from "@/components/navigation"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { AlertTriangle, Clock, Info, ShieldAlert } from "lucide-react"

export default function NotificationsPage() {
  return (
    <main className="flex min-h-screen flex-col bg-gradient-to-b from-yellow-50 to-sky-50">
      <Navigation />

      <div className="container px-4 py-6 mx-auto">
        <h1 className="text-3xl font-bold text-green-600 mb-6">Thông Báo</h1>

        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-6">
            <TabsTrigger value="all">Tất Cả</TabsTrigger>
            <TabsTrigger value="alerts">Cảnh Báo</TabsTrigger>
            <TabsTrigger value="maintenance">Bảo Trì</TabsTrigger>
            <TabsTrigger value="updates">Cập Nhật</TabsTrigger>
          </TabsList>

          <TabsContent value="all">
            <div className="space-y-4">
              {notifications.map((notification, index) => (
                <NotificationCard key={index} notification={notification} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="alerts">
            <div className="space-y-4">
              {notifications
                .filter((notification) => notification.type === "alert")
                .map((notification, index) => (
                  <NotificationCard key={index} notification={notification} />
                ))}
            </div>
          </TabsContent>

          <TabsContent value="maintenance">
            <div className="space-y-4">
              {notifications
                .filter((notification) => notification.type === "maintenance")
                .map((notification, index) => (
                  <NotificationCard key={index} notification={notification} />
                ))}
            </div>
          </TabsContent>

          <TabsContent value="updates">
            <div className="space-y-4">
              {notifications
                .filter((notification) => notification.type === "update")
                .map((notification, index) => (
                  <NotificationCard key={index} notification={notification} />
                ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </main>
  )
}

interface Notification {
  id: number
  title: string
  description: string
  date: string
  type: "alert" | "maintenance" | "update" | "info"
  priority: "high" | "medium" | "low"
  read: boolean
  actionText?: string
  actionLink?: string
}

function NotificationCard({ notification }: { notification: Notification }) {
  const getIcon = (type: string) => {
    switch (type) {
      case "alert":
        return <AlertTriangle className="h-5 w-5 text-red-500" />
      case "maintenance":
        return <ShieldAlert className="h-5 w-5 text-orange-500" />
      case "update":
        return <Info className="h-5 w-5 text-blue-500" />
      default:
        return <Info className="h-5 w-5 text-gray-500" />
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800"
      case "medium":
        return "bg-orange-100 text-orange-800"
      case "low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <Card className={`${notification.read ? "bg-white" : "bg-yellow-50"}`}>
      <CardHeader className="flex flex-row items-start justify-between pb-2">
        <div className="flex items-center space-x-2">
          {getIcon(notification.type)}
          <CardTitle className="text-lg">{notification.title}</CardTitle>
          {!notification.read && (
            <Badge variant="outline" className="ml-2 bg-blue-100 text-blue-800">
              Mới
            </Badge>
          )}
        </div>
        <Badge className={getPriorityColor(notification.priority)}>
          {notification.priority === "high" ? "Cao" : notification.priority === "medium" ? "Trung bình" : "Thấp"}
        </Badge>
      </CardHeader>
      <CardContent>
        <CardDescription className="text-base text-gray-700 mb-4">{notification.description}</CardDescription>
        <div className="flex items-center justify-between">
          <div className="flex items-center text-sm text-gray-500">
            <Clock className="mr-1 h-4 w-4" />
            {notification.date}
          </div>
          {notification.actionText && (
            <Button variant="outline" size="sm" className="text-yellow-600 border-yellow-600 hover:bg-yellow-50">
              {notification.actionText}
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

const notifications: Notification[] = [
  {
    id: 1,
    title: "Cảnh báo dư lượng thuốc trừ sâu cao",
    description:
      "Phát hiện dư lượng thuốc trừ sâu vượt ngưỡng cho phép trong lô rau cải xanh tại siêu thị ABC. Vui lòng kiểm tra kỹ trước khi sử dụng.",
    date: "Hôm nay, 10:30",
    type: "alert",
    priority: "high",
    read: false,
    actionText: "Xem chi tiết",
    actionLink: "/alerts/1",
  },
  {
    id: 2,
    title: "Đặt lịch bảo trì cảm biến",
    description: "Cảm biến của bạn cần được bảo trì định kỳ. Vui lòng đặt lịch với kỹ thuật viên của chúng tôi.",
    date: "Hôm qua, 15:45",
    type: "maintenance",
    priority: "medium",
    read: false,
    actionText: "Đặt lịch",
    actionLink: "/maintenance",
  },
  {
    id: 3,
    title: "Cập nhật cơ sở dữ liệu thực phẩm",
    description:
      "Chúng tôi vừa cập nhật cơ sở dữ liệu với hơn 1,000 loại thực phẩm mới và thông tin dinh dưỡng chi tiết.",
    date: "2 ngày trước",
    type: "update",
    priority: "low",
    read: true,
  },
  {
    id: 4,
    title: "Phát hiện vi khuẩn E.coli trong thịt bò",
    description:
      "Cảnh báo: Phát hiện vi khuẩn E.coli trong lô thịt bò nhập khẩu từ nhà cung cấp XYZ. Vui lòng kiểm tra sản phẩm của bạn.",
    date: "3 ngày trước",
    type: "alert",
    priority: "high",
    read: true,
    actionText: "Kiểm tra sản phẩm",
    actionLink: "/check-product",
  },
  {
    id: 5,
    title: "Khuyến mãi từ đối tác",
    description: "Siêu thị Organic Food đang có chương trình giảm giá 20% cho tất cả các sản phẩm rau củ hữu cơ.",
    date: "1 tuần trước",
    type: "info",
    priority: "low",
    read: true,
    actionText: "Mua ngay",
    actionLink: "/shop",
  },
]

