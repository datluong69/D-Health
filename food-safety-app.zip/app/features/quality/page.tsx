import Navigation from "@/components/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ShieldCheck, AlertTriangle, Check, X, Camera } from "lucide-react"
import Link from "next/link"

export default function QualityCheckPage() {
  return (
    <main className="flex min-h-screen flex-col bg-gradient-to-b from-green-50 to-sky-50">
      <Navigation />

      <div className="container px-4 py-6 mx-auto">
        <div className="flex items-center mb-6">
          <ShieldCheck className="h-8 w-8 text-green-600 mr-3" />
          <h1 className="text-3xl font-bold text-green-600">Kiểm Tra Chất Lượng</h1>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Công Nghệ Phát Hiện Chất Lượng</CardTitle>
                <CardDescription>
                  Sử dụng AI tiên tiến để phân tích và phát hiện các vấn đề về chất lượng thực phẩm
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <p>
                    Tính năng Kiểm Tra Chất Lượng của D Healthy Life sử dụng công nghệ trí tuệ nhân tạo tiên tiến để
                    phân tích hình ảnh thực phẩm và phát hiện các vấn đề về chất lượng như:
                  </p>
                  <ul className="list-disc list-inside space-y-2">
                    <li>Dư lượng thuốc trừ sâu và hóa chất độc hại</li>
                    <li>Chất bảo quản vượt ngưỡng cho phép</li>
                    <li>Thực phẩm giả, kém chất lượng hoặc hết hạn</li>
                    <li>Dấu hiệu nhiễm khuẩn hoặc nấm mốc</li>
                    <li>Phụ gia thực phẩm không được phép sử dụng</li>
                  </ul>

                  <div className="mt-6">
                    <h3 className="text-lg font-medium mb-2">Cách sử dụng:</h3>
                    <ol className="list-decimal list-inside space-y-2">
                      <li>Chụp ảnh thực phẩm hoặc quét mã QR trên bao bì</li>
                      <li>Hệ thống AI sẽ phân tích và đưa ra kết quả trong vài giây</li>
                      <li>Nhận báo cáo chi tiết về chất lượng và độ an toàn</li>
                      <li>Lưu kết quả để theo dõi và so sánh sau này</li>
                    </ol>
                  </div>

                  <div className="flex justify-center mt-6">
                    <Button className="bg-green-600 hover:bg-green-700" asChild>
                      <Link href="/scan">
                        <Camera className="mr-2 h-4 w-4" />
                        Bắt đầu kiểm tra ngay
                      </Link>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Kết Quả Kiểm Tra Mẫu</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <QualityResultCard
                      title="Rau cải xanh hữu cơ"
                      status="safe"
                      issues={[]}
                      recommendations={["Rửa kỹ trước khi sử dụng", "Bảo quản trong tủ lạnh tối đa 5 ngày"]}
                    />
                    <QualityResultCard
                      title="Thịt bò nhập khẩu"
                      status="warning"
                      issues={["Phát hiện dư lượng kháng sinh vượt ngưỡng cho phép 5%"]}
                      recommendations={["Nấu chín kỹ trước khi sử dụng", "Không phù hợp cho trẻ em dưới 5 tuổi"]}
                    />
                    <QualityResultCard
                      title="Táo Fuji"
                      status="safe"
                      issues={[]}
                      recommendations={[
                        "Rửa kỹ dưới vòi nước để loại bỏ lớp sáp bảo quản",
                        "Có thể ăn cả vỏ sau khi rửa sạch",
                      ]}
                    />
                    <QualityResultCard
                      title="Cá hồi phi lê"
                      status="danger"
                      issues={["Phát hiện dấu hiệu không tươi", "Có khả năng nhiễm khuẩn Listeria"]}
                      recommendations={["Không nên sử dụng", "Trả lại cửa hàng hoặc tiêu hủy an toàn"]}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Tiêu Chuẩn An Toàn</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <p className="text-sm">D Healthy Life áp dụng các tiêu chuẩn an toàn thực phẩm quốc tế, bao gồm:</p>
                  <ul className="list-disc list-inside text-sm space-y-1">
                    <li>Tiêu chuẩn Codex Alimentarius (FAO/WHO)</li>
                    <li>Quy định an toàn thực phẩm của Bộ Y tế Việt Nam</li>
                    <li>Tiêu chuẩn FDA (Hoa Kỳ) và EFSA (Châu Âu)</li>
                    <li>Tiêu chuẩn JAS (Nhật Bản) và CFS (Hồng Kông)</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Thống Kê</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Độ chính xác phát hiện:</span>
                    <span className="font-medium">95.7%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-green-600 h-2 rounded-full" style={{ width: "95.7%" }}></div>
                  </div>

                  <div className="flex justify-between items-center mt-4">
                    <span className="text-sm">Thời gian phân tích trung bình:</span>
                    <span className="font-medium">3.2 giây</span>
                  </div>

                  <div className="flex justify-between items-center mt-4">
                    <span className="text-sm">Số lượng mẫu đã phân tích:</span>
                    <span className="font-medium">1,245,678</span>
                  </div>

                  <div className="flex justify-between items-center mt-4">
                    <span className="text-sm">Cơ sở dữ liệu hóa chất:</span>
                    <span className="font-medium">5,000+</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Câu Hỏi Thường Gặp</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm font-medium">Độ chính xác của kết quả kiểm tra?</h3>
                    <p className="text-sm text-gray-600 mt-1">
                      Hệ thống có độ chính xác trên 95% đối với các chất phổ biến, nhưng vẫn nên kết hợp với kiểm tra
                      chuyên nghiệp cho các trường hợp nghiêm trọng.
                    </p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium">Có thể kiểm tra thực phẩm đã chế biến không?</h3>
                    <p className="text-sm text-gray-600 mt-1">
                      Có, nhưng độ chính xác sẽ giảm xuống khoảng 80-85% do quá trình chế biến làm thay đổi cấu trúc và
                      thành phần hóa học.
                    </p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium">Làm thế nào để có kết quả chính xác nhất?</h3>
                    <p className="text-sm text-gray-600 mt-1">
                      Chụp ảnh trong điều kiện ánh sáng tốt, đặt thực phẩm trên nền trắng, và chụp nhiều góc khác nhau.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </main>
  )
}

interface QualityResultCardProps {
  title: string
  status: "safe" | "warning" | "danger"
  issues: string[]
  recommendations: string[]
}

function QualityResultCard({ title, status, issues, recommendations }: QualityResultCardProps) {
  const statusConfig = {
    safe: {
      icon: <Check className="h-5 w-5 text-green-600" />,
      label: "An toàn",
      bgColor: "bg-green-50",
      borderColor: "border-green-200",
    },
    warning: {
      icon: <AlertTriangle className="h-5 w-5 text-amber-600" />,
      label: "Cần chú ý",
      bgColor: "bg-amber-50",
      borderColor: "border-amber-200",
    },
    danger: {
      icon: <X className="h-5 w-5 text-red-600" />,
      label: "Không an toàn",
      bgColor: "bg-red-50",
      borderColor: "border-red-200",
    },
  }

  const config = statusConfig[status]

  return (
    <div className={`border rounded-lg p-4 ${config.bgColor} ${config.borderColor}`}>
      <div className="flex justify-between items-start mb-3">
        <h3 className="font-medium">{title}</h3>
        <div className="flex items-center px-2 py-1 rounded-full bg-white">
          {config.icon}
          <span className="text-xs ml-1">{config.label}</span>
        </div>
      </div>

      {issues.length > 0 && (
        <div className="mb-3">
          <h4 className="text-xs font-medium mb-1">Vấn đề phát hiện:</h4>
          <ul className="text-xs space-y-1">
            {issues.map((issue, index) => (
              <li key={index} className="flex items-start">
                <span className="inline-block w-1 h-1 rounded-full bg-red-500 mt-1.5 mr-1.5"></span>
                {issue}
              </li>
            ))}
          </ul>
        </div>
      )}

      <div>
        <h4 className="text-xs font-medium mb-1">Khuyến nghị:</h4>
        <ul className="text-xs space-y-1">
          {recommendations.map((rec, index) => (
            <li key={index} className="flex items-start">
              <span className="inline-block w-1 h-1 rounded-full bg-green-500 mt-1.5 mr-1.5"></span>
              {rec}
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}

