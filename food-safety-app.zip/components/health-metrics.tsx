"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

export default function HealthMetrics() {
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle>Chỉ Số Dinh Dưỡng & Sức Khỏe</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="daily">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="daily">Hàng Ngày</TabsTrigger>
            <TabsTrigger value="weekly">Hàng Tuần</TabsTrigger>
            <TabsTrigger value="monthly">Hàng Tháng</TabsTrigger>
          </TabsList>

          <TabsContent value="daily" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <MetricCard title="Calo" value="1,850" target="2,000" unit="kcal" progress={92.5} />
              <MetricCard title="Protein" value="85" target="90" unit="g" progress={94.4} />
              <MetricCard title="Nước" value="1.8" target="2.5" unit="lít" progress={72} />
            </div>

            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={dailyNutritionData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="calories" stroke="#f59e0b" strokeWidth={2} />
                  <Line type="monotone" dataKey="protein" stroke="#0ea5e9" strokeWidth={2} />
                  <Line type="monotone" dataKey="carbs" stroke="#10b981" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Phân Bổ Dinh Dưỡng</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={nutritionDistribution}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        >
                          {nutritionDistribution.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Vitamin & Khoáng Chất</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={vitaminsData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="percent" fill="#f59e0b" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="weekly">
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={weeklyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="day" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="calories" stroke="#f59e0b" strokeWidth={2} />
                  <Line type="monotone" dataKey="protein" stroke="#0ea5e9" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>

          <TabsContent value="monthly">
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={monthlyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="week" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="calories" fill="#f59e0b" />
                  <Bar dataKey="protein" fill="#0ea5e9" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

function MetricCard({
  title,
  value,
  target,
  unit,
  progress,
}: {
  title: string
  value: string
  target: string
  unit: string
  progress: number
}) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex justify-between items-center mb-2">
          <h3 className="font-medium text-gray-500">{title}</h3>
          <span className="text-xs text-gray-500">
            Mục tiêu: {target} {unit}
          </span>
        </div>
        <div className="flex items-end space-x-1 mb-2">
          <span className="text-2xl font-bold">{value}</span>
          <span className="text-sm text-gray-500 mb-1">{unit}</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div className="bg-yellow-500 h-2 rounded-full" style={{ width: `${progress}%` }}></div>
        </div>
        <div className="mt-1 text-right text-xs text-gray-500">{progress}%</div>
      </CardContent>
    </Card>
  )
}

const COLORS = ["#f59e0b", "#0ea5e9", "#10b981", "#8b5cf6", "#ec4899"]

const dailyNutritionData = [
  { time: "6:00", calories: 350, protein: 15, carbs: 45 },
  { time: "9:00", calories: 550, protein: 25, carbs: 65 },
  { time: "12:00", calories: 950, protein: 45, carbs: 110 },
  { time: "15:00", calories: 1200, protein: 55, carbs: 140 },
  { time: "18:00", calories: 1650, protein: 75, carbs: 190 },
  { time: "21:00", calories: 1850, protein: 85, carbs: 220 },
]

const nutritionDistribution = [
  { name: "Protein", value: 25 },
  { name: "Carbs", value: 45 },
  { name: "Chất béo", value: 30 },
]

const vitaminsData = [
  { name: "Vit A", percent: 85 },
  { name: "Vit C", percent: 120 },
  { name: "Vit D", percent: 60 },
  { name: "Vit E", percent: 75 },
  { name: "Canxi", percent: 65 },
  { name: "Sắt", percent: 90 },
]

const weeklyData = [
  { day: "T2", calories: 1950, protein: 88 },
  { day: "T3", calories: 1850, protein: 82 },
  { day: "T4", calories: 2100, protein: 95 },
  { day: "T5", calories: 1750, protein: 78 },
  { day: "T6", calories: 2050, protein: 92 },
  { day: "T7", calories: 2200, protein: 98 },
  { day: "CN", calories: 1900, protein: 85 },
]

const monthlyData = [
  { week: "Tuần 1", calories: 13650, protein: 615 },
  { week: "Tuần 2", calories: 14200, protein: 640 },
  { week: "Tuần 3", calories: 13800, protein: 625 },
  { week: "Tuần 4", calories: 14500, protein: 655 },
]

