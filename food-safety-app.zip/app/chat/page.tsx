"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent } from "@/components/ui/card"
import Navigation from "@/components/navigation"
import { Send, Image, Paperclip, Mic } from "lucide-react"

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      content:
        "Xin chào! Tôi là trợ lý ảo D Healthy Life. Tôi có thể giúp gì cho bạn về thực phẩm và dinh dưỡng hôm nay?",
      sender: "bot",
      timestamp: new Date().toISOString(),
    },
  ])
  const [inputValue, setInputValue] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if (!inputValue.trim()) return

    // Add user message
    const userMessage: Message = {
      id: messages.length + 1,
      content: inputValue,
      sender: "user",
      timestamp: new Date().toISOString(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInputValue("")
    setIsTyping(true)

    // Simulate bot response after a delay
    setTimeout(() => {
      const botResponses = [
        "Tôi có thể giúp bạn phân tích thành phần dinh dưỡng của thực phẩm. Hãy gửi cho tôi hình ảnh món ăn bạn muốn phân tích.",
        "Bạn có thể quét mã QR trên bao bì sản phẩm để kiểm tra nguồn gốc và chất lượng.",
        "Tôi đề xuất bạn nên tăng cường rau xanh và giảm thực phẩm chế biến sẵn để cải thiện sức khỏe.",
        "Dựa trên lịch sử ăn uống của bạn, tôi nhận thấy bạn đang thiếu vitamin D và canxi. Hãy bổ sung thêm sữa và các sản phẩm từ sữa.",
        "Tôi có thể giúp bạn lên kế hoạch bữa ăn phù hợp với mục tiêu giảm cân của bạn. Bạn muốn tôi gợi ý thực đơn không?",
      ]

      const randomResponse = botResponses[Math.floor(Math.random() * botResponses.length)]

      const botMessage: Message = {
        id: messages.length + 2,
        content: randomResponse,
        sender: "bot",
        timestamp: new Date().toISOString(),
      }

      setMessages((prev) => [...prev, botMessage])
      setIsTyping(false)
    }, 1500)
  }

  return (
    <main className="flex min-h-screen flex-col bg-gradient-to-b from-green-50 to-sky-50">
      <Navigation />

      <div className="container flex flex-col flex-1 px-4 py-6 mx-auto">
        <h1 className="text-3xl font-bold text-green-600 mb-6">Trò Chuyện Với Chuyên Gia</h1>

        <Card className="flex-1 flex flex-col overflow-hidden">
          <CardContent className="flex-1 flex flex-col p-0">
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((message) => (
                <div key={message.id} className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}>
                  <div className="flex items-start max-w-[80%]">
                    {message.sender === "bot" && (
                      <Avatar className="mr-2">
                        <AvatarImage src="/placeholder.svg?height=40&width=40" />
                        <AvatarFallback className="bg-green-600 text-white">DH</AvatarFallback>
                      </Avatar>
                    )}
                    <div
                      className={`rounded-lg p-3 ${
                        message.sender === "user" ? "bg-sky-500 text-white" : "bg-gray-100 text-gray-800"
                      }`}
                    >
                      <p>{message.content}</p>
                      <p className="text-xs opacity-70 mt-1">
                        {new Date(message.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </p>
                    </div>
                    {message.sender === "user" && (
                      <Avatar className="ml-2">
                        <AvatarImage src="/placeholder.svg?height=40&width=40" />
                        <AvatarFallback className="bg-sky-500 text-white">U</AvatarFallback>
                      </Avatar>
                    )}
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="flex items-start max-w-[80%]">
                    <Avatar className="mr-2">
                      <AvatarImage src="/placeholder.svg?height=40&width=40" />
                      <AvatarFallback className="bg-green-600 text-white">DH</AvatarFallback>
                    </Avatar>
                    <div className="rounded-lg p-3 bg-gray-100 text-gray-800">
                      <div className="flex space-x-1">
                        <div
                          className="w-2 h-2 rounded-full bg-gray-400 animate-bounce"
                          style={{ animationDelay: "0ms" }}
                        ></div>
                        <div
                          className="w-2 h-2 rounded-full bg-gray-400 animate-bounce"
                          style={{ animationDelay: "150ms" }}
                        ></div>
                        <div
                          className="w-2 h-2 rounded-full bg-gray-400 animate-bounce"
                          style={{ animationDelay: "300ms" }}
                        ></div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            <form onSubmit={handleSendMessage} className="p-4 border-t">
              <div className="flex items-center space-x-2">
                <Button type="button" size="icon" variant="ghost">
                  <Paperclip className="h-5 w-5 text-gray-500" />
                </Button>
                <Button type="button" size="icon" variant="ghost">
                  <Image className="h-5 w-5 text-gray-500" />
                </Button>
                <Input
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  placeholder="Nhập tin nhắn của bạn..."
                  className="flex-1"
                />
                <Button type="button" size="icon" variant="ghost">
                  <Mic className="h-5 w-5 text-gray-500" />
                </Button>
                <Button type="submit" size="icon" className="bg-green-600 hover:bg-green-700">
                  <Send className="h-5 w-5" />
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </main>
  )
}

interface Message {
  id: number
  content: string
  sender: "user" | "bot"
  timestamp: string
}

