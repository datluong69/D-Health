import Navigation from "@/components/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Utensils, Camera, BarChart3, PieChart, Apple, Carrot, Beef, Fish } from "lucide-react"
import Link from "next/link"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart as RePieChart,
  Pie,
  Cell,
} from "recharts"

export default function NutritionAnalysisPage() {
  return (
    <main className="flex min-h-screen flex-col bg-gradient-to-b from-green-50 to-sky-50">
      <Navigation />

      <div className="container px-4 py-6 mx-auto">
        <div className="flex items-center mb-6">
          <Utensils className="h-8 w-8 text-green-600 mr-3" />
          <h1 className="text-3xl font-bold text-green-600">Phân Tích Dinh Dưỡng</h1>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Công Nghệ Phân Tích Dinh Dưỡng</CardTitle>
                <CardDescription>Phân tích chi tiết thành phần dinh dưỡng trong thực phẩm bằng AI</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <p>
                    Tính năng Phân Tích Dinh Dưỡng của D Healthy Life sử dụng trí tuệ nhân tạo để nhận diện thực phẩm và
                    phân tích chi tiết thành phần dinh dưỡng, bao gồm:
                  </p>
                  <ul className="list-disc list-inside space-y-2">
                    <li>Hàm lượng calo, protein, chất béo, carbohydrate</li>
                    <li>Vitamin và khoáng chất</li>
                    <li>Chất xơ, đường và muối</li>
                    <li>Axit béo omega-3, omega-6</li>
                    <li>Chất chống oxy hóa và phytochemical</li>
                  </ul>

                  <div className="mt-6">
                    <h3 className="text-lg font-medium mb-2">Cách sử dụng:</h3>
                    <ol className="list-decimal list-inside space-y-2">
                      <li>Chụp ảnh món ăn hoặc thực phẩm</li>
                      <li>AI sẽ nhận diện các thành phần và ước tính khối lượng</li>
                      <li>Nhận báo cáo chi tiết về thành phần dinh dưỡng</li>
                      <li>Lưu vào nhật ký dinh dưỡng để theo dõi chế độ ăn uống</li>
                    </ol>
                  </div>

                  <div className="flex justify-center mt-6">
                    <Button className="bg-green-600 hover:bg-green-700" asChild>
                      <Link href="/scan">
                        <Camera className="mr-2 h-4 w-4" />
                        Phân tích thực phẩm ngay
                      </Link>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Phân Tích Mẫu</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="fruits">
                  <TabsList className="grid w-full grid-cols-4 mb-6">
                    <TabsTrigger value="fruits">
                      <div className="flex items-center">
                        <Apple className="h-4 w-4 mr-2" />
                        Trái cây
                      </div>
                    </TabsTrigger>
                    <TabsTrigger value="vegetables">
                      <div className="flex items-center">
                        <Carrot className="h-4 w-4 mr-2" />
                        Rau củ
                      </div>
                    </TabsTrigger>
                    <TabsTrigger value="meat">
                      <div className="flex items-center">
                        <Beef className="h-4 w-4 mr-2" />
                        Thịt
                      </div>
                    </TabsTrigger>
                    <TabsTrigger value="seafood">
                      <div className="flex items-center">
                        <Fish className="h-4 w-4 mr-2" />
                        Hải sản
                      </div>
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="fruits">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <NutritionCard
                        name="Táo"
                        image="/placeholder.svg?height=100&width=100"
                        calories={52}
                        protein={0.3}
                        fat={0.2}
                        carbs={14}
                        fiber={2.4}
                        vitamins={["Vitamin C", "Vitamin K"]}
                        minerals={["Kali", "Mangan"]}
                      />
                      <NutritionCard
                        name="Chuối"
                        image="/placeholder.svg?height=100&width=100"
                        calories={89}
                        protein={1.1}
                        fat={0.3}
                        carbs={22.8}
                        fiber={2.6}
                        vitamins={["Vitamin B6", "Vitamin C"]}
                        minerals={["Kali", "Magie"]}
                      />
                      <NutritionCard
                        name="Cam"
                        image="/placeholder.svg?height=100&width=100"
                        calories={47}
                        protein={0.9}
                        fat={0.1}
                        carbs={11.8}
                        fiber={2.4}
                        vitamins={["Vitamin C", "Thiamin"]}
                        minerals={["Canxi", "Kali"]}
                      />
                      <NutritionCard
                        name="Dâu tây"
                        image="/placeholder.svg?height=100&width=100"
                        calories={32}
                        protein={0.7}
                        fat={0.3}
                        carbs={7.7}
                        fiber={2.0}
                        vitamins={["Vitamin C", "Folate"]}
                        minerals={["Mangan", "Kali"]}
                      />
                    </div>
                  </TabsContent>

                  <TabsContent value="vegetables">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <NutritionCard
                        name="Cà rốt"
                        image="/placeholder.svg?height=100&width=100"
                        calories={41}
                        protein={0.9}
                        fat={0.2}
                        carbs={9.6}
                        fiber={2.8}
                        vitamins={["Vitamin A", "Vitamin K"]}
                        minerals={["Kali", "Mangan"]}
                      />
                      <NutritionCard
                        name="Bông cải xanh"
                        image="/placeholder.svg?height=100&width=100"
                        calories={34}
                        protein={2.8}
                        fat={0.4}
                        carbs={6.6}
                        fiber={2.6}
                        vitamins={["Vitamin C", "Vitamin K"]}
                        minerals={["Kali", "Canxi"]}
                      />
                      <NutritionCard
                        name="Cà chua"
                        image="/placeholder.svg?height=100&width=100"
                        calories={18}
                        protein={0.9}
                        fat={0.2}
                        carbs={3.9}
                        fiber={1.2}
                        vitamins={["Vitamin C", "Vitamin K"]}
                        minerals={["Kali", "Mangan"]}
                      />
                      <NutritionCard
                        name="Rau chân vịt"
                        image="/placeholder.svg?height=100&width=100"
                        calories={23}
                        protein={2.9}
                        fat={0.4}
                        carbs={3.6}
                        fiber={2.2}
                        vitamins={["Vitamin A", "Vitamin K"]}
                        minerals={["Sắt", "Canxi"]}
                      />
                    </div>
                  </TabsContent>

                  <TabsContent value="meat">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <NutritionCard
                        name="Thịt bò nạc"
                        image="/placeholder.svg?height=100&width=100"
                        calories={250}
                        protein={26}
                        fat={17}
                        carbs={0}
                        fiber={0}
                        vitamins={["Vitamin B12", "Niacin"]}
                        minerals={["Sắt", "Kẽm"]}
                      />
                      <NutritionCard
                        name="Ức gà"
                        image="/placeholder.svg?height=100&width=100"
                        calories={165}
                        protein={31}
                        fat={3.6}
                        carbs={0}
                        fiber={0}
                        vitamins={["Vitamin B6", "Niacin"]}
                        minerals={["Phốt pho", "Selen"]}
                      />
                      <NutritionCard
                        name="Thịt heo nạc"
                        image="/placeholder.svg?height=100&width=100"
                        calories={242}
                        protein={26}
                        fat={14}
                        carbs={0}
                        fiber={0}
                        vitamins={["Thiamin", "Vitamin B6"]}
                        minerals={["Kẽm", "Selen"]}
                      />
                      <NutritionCard
                        name="Thịt cừu"
                        image="/placeholder.svg?height=100&width=100"
                        calories={294}
                        protein={25}
                        fat={21}
                        carbs={0}
                        fiber={0}
                        vitamins={["Vitamin B12", "Niacin"]}
                        minerals={["Sắt", "Kẽm"]}
                      />
                    </div>
                  </TabsContent>

                  <TabsContent value="seafood">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <NutritionCard
                        name="Cá hồi"
                        image="/placeholder.svg?height=100&width=100"
                        calories={208}
                        protein={20}
                        fat={13}
                        carbs={0}
                        fiber={0}
                        vitamins={["Vitamin D", "Vitamin B12"]}
                        minerals={["Selen", "Phốt pho"]}
                      />
                      <NutritionCard
                        name="Tôm"
                        image="/placeholder.svg?height=100&width=100"
                        calories={99}
                        protein={24}
                        fat={0.3}
                        carbs={0}
                        fiber={0}
                        vitamins={["Vitamin B12", "Niacin"]}
                        minerals={["Selen", "Phốt pho"]}
                      />
                      <NutritionCard
                        name="Cá ngừ"
                        image="/placeholder.svg?height=100&width=100"
                        calories={184}
                        protein={30}
                        fat={6}
                        carbs={0}
                        fiber={0}
                        vitamins={["Vitamin D", "Vitamin B12"]}
                        minerals={["Selen", "Magie"]}
                      />
                      <NutritionCard
                        name="Mực"
                        image="/placeholder.svg?height=100&width=100"
                        calories={92}
                        protein={15.6}
                        fat={1.4}
                        carbs={3.1}
                        fiber={0}
                        vitamins={["Vitamin B12", "Riboflavin"]}
                        minerals={["Đồng", "Selen"]}
                      />
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="h-5 w-5 mr-2 text-green-600" />
                  Thống Kê Dinh Dưỡng
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={nutritionData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="protein" fill="#10b981" name="Protein (g)" />
                      <Bar dataKey="fat" fill="#f59e0b" name="Chất béo (g)" />
                      <Bar dataKey="carbs" fill="#3b82f6" name="Carbs (g)" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <PieChart className="h-5 w-5 mr-2 text-green-600" />
                  Phân Bổ Calo
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <RePieChart>
                      <Pie
                        data={calorieDistribution}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {calorieDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </RePieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Lợi Ích</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start">
                    <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center mr-3 flex-shrink-0">
                      <span className="text-green-600 font-medium">1</span>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium">Theo dõi chế độ ăn uống</h3>
                      <p className="text-sm text-gray-600 mt-1">
                        Ghi lại thông tin dinh dưỡng hàng ngày để đảm bảo bạn đang nhận đủ các chất dinh dưỡng cần
                        thiết.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center mr-3 flex-shrink-0">
                      <span className="text-green-600 font-medium">2</span>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium">Lập kế hoạch bữa ăn thông minh</h3>
                      <p className="text-sm text-gray-600 mt-1">
                        Sử dụng dữ liệu dinh dưỡng để tạo kế hoạch bữa ăn cân bằng phù hợp với mục tiêu sức khỏe của
                        bạn.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center mr-3 flex-shrink-0">
                      <span className="text-green-600 font-medium">3</span>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium">Phát hiện thiếu hụt dinh dưỡng</h3>
                      <p className="text-sm text-gray-600 mt-1">
                        Nhận cảnh báo khi chế độ ăn của bạn thiếu các vitamin hoặc khoáng chất quan trọng.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center mr-3 flex-shrink-0">
                      <span className="text-green-600 font-medium">4</span>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium">Đạt mục tiêu sức khỏe</h3>
                      <p className="text-sm text-gray-600 mt-1">
                        Theo dõi tiến trình hướng tới mục tiêu cá nhân như giảm cân, tăng cơ, hoặc kiểm soát bệnh mãn
                        tính.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </main>
  )
}

interface NutritionCardProps {
  name: string
  image: string
  calories: number
  protein: number
  fat: number
  carbs: number
  fiber: number
  vitamins: string[]
  minerals: string[]
}

function NutritionCard({ name, image, calories, protein, fat, carbs, fiber, vitamins, minerals }: NutritionCardProps) {
  return (
    <div className="border rounded-lg p-4 bg-white">
      <div className="flex items-center mb-3">
        <img src={image || "/placeholder.svg"} alt={name} className="w-12 h-12 object-cover rounded-md mr-3" />
        <h3 className="font-medium">{name}</h3>
      </div>

      <div className="grid grid-cols-2 gap-2 mb-3">
        <div className="text-center p-2 bg-green-50 rounded">
          <p className="text-xs text-gray-500">Calories</p>
          <p className="font-medium">{calories} kcal</p>
        </div>
        <div className="text-center p-2 bg-blue-50 rounded">
          <p className="text-xs text-gray-500">Protein</p>
          <p className="font-medium">{protein}g</p>
        </div>
        <div className="text-center p-2 bg-yellow-50 rounded">
          <p className="text-xs text-gray-500">Chất béo</p>
          <p className="font-medium">{fat}g</p>
        </div>
        <div className="text-center p-2 bg-purple-50 rounded">
          <p className="text-xs text-gray-500">Carbs</p>
          <p className="font-medium">{carbs}g</p>
        </div>
      </div>

      <div className="text-xs">
        <div className="flex mb-1">
          <span className="font-medium w-20">Chất xơ:</span>
          <span>{fiber}g</span>
        </div>
        <div className="flex mb-1">
          <span className="font-medium w-20">Vitamin:</span>
          <span>{vitamins.join(", ")}</span>
        </div>
        <div className="flex">
          <span className="font-medium w-20">Khoáng chất:</span>
          <span>{minerals.join(", ")}</span>
        </div>
      </div>
    </div>
  )
}

const nutritionData = [
  { name: "Táo", protein: 0.3, fat: 0.2, carbs: 14 },
  { name: "Chuối", protein: 1.1, fat: 0.3, carbs: 22.8 },
  { name: "Ức gà", protein: 31, fat: 3.6, carbs: 0 },
  { name: "Cá hồi", protein: 20, fat: 13, carbs: 0 },
  { name: "Bông cải", protein: 2.8, fat: 0.4, carbs: 6.6 },
]

const calorieDistribution = [
  { name: "Protein", value: 25 },
  { name: "Chất béo", value: 30 },
  { name: "Carbs", value: 45 },
]

const COLORS = ["#10b981", "#f59e0b", "#3b82f6", "#8b5cf6", "#ec4899"]

