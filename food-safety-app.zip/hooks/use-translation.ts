"use client"

import type React from "react"

import { useState, useEffect, createContext, useContext } from "react"

// Define available languages
export type Language = "vi" | "en" | "zh" | "ja" | "ko" | "fr" | "de" | "es" | "ru" | "ar" | "th"

// Translation context
interface TranslationContextType {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: string) => string
}

const TranslationContext = createContext<TranslationContextType>({
  language: "vi",
  setLanguage: () => {},
  t: (key) => key,
})

// Translation provider component
export function TranslationProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>("vi")
  const [translations, setTranslations] = useState<Record<string, string>>({})

  useEffect(() => {
    // Load translations for the selected language
    // In a real app, this would fetch from a server or import from files
    const loadTranslations = async () => {
      // Simulating loading translations
      setTranslations(getTranslations(language))
    }

    loadTranslations()
  }, [language])

  const t = (key: string): string => {
    return translations[key] || key
  }

  return <TranslationContext.Provider value={{ language, setLanguage, t }}>{children}</TranslationContext.Provider>
}

// Hook to use translations
export function useTranslation() {
  const context = useContext(TranslationContext)
  if (!context) {
    throw new Error("useTranslation must be used within a TranslationProvider")
  }
  return context
}

// Language names for display
export const languageNames: Record<Language, string> = {
  vi: "Tiếng Việt",
  en: "English",
  zh: "中文",
  ja: "日本語",
  ko: "한국어",
  fr: "Français",
  de: "Deutsch",
  es: "Español",
  ru: "Русский",
  ar: "العربية",
  th: "ไทย",
}

// Mock translations
function getTranslations(language: Language): Record<string, string> {
  const translations: Record<Language, Record<string, string>> = {
    vi: {
      "app.title": "D Healthy Life",
      "app.subtitle": "Sống Khỏe Mỗi Ngày",
      "scanner.instruction": "Chụp ảnh hoặc quét mã QR để phân tích thực phẩm",
      "scanner.openCamera": "Mở Camera",
      "scanner.uploadPhoto": "Tải Ảnh Lên",
      "scanner.analyze": "Phân Tích",
      "scanner.analyzing": "Đang phân tích thực phẩm...",
      "scanner.pleaseWait": "Vui lòng đợi trong giây lát",
      "scanner.safe": "An Toàn",
      "scanner.warning": "Cảnh Báo",
      "scanner.warnings": "Cảnh Báo",
      "scanner.recommendations": "Khuyến Nghị",
      "scanner.scanAgain": "Quét Lại",
      "scanner.viewDetails": "Xem Chi Tiết",
      "nutrition.info": "Thông Tin Dinh Dưỡng (100g)",
      "nutrition.calories": "Calo",
      "nutrition.protein": "Đạm",
      "nutrition.fat": "Chất béo",
      "nutrition.carbs": "Carbs",
      "nutrition.fiber": "Chất xơ",
      "nutrition.sugar": "Đường",
      "nutrition.recommendation.vitaminC": "Nguồn vitamin C tốt",
      "nutrition.recommendation.fiber": "Giàu chất xơ",
      "nutrition.recommendation.eatWithSkin": "Ăn với vỏ để tối đa hóa dinh dưỡng",
    },
    en: {
      "app.title": "D Healthy Life",
      "app.subtitle": "Live Healthy Every Day",
      "scanner.instruction": "Take a photo or scan QR code to analyze food",
      "scanner.openCamera": "Open Camera",
      "scanner.uploadPhoto": "Upload Photo",
      "scanner.analyze": "Analyze",
      "scanner.analyzing": "Analyzing food...",
      "scanner.pleaseWait": "Please wait a moment",
      "scanner.safe": "Safe",
      "scanner.warning": "Warning",
      "scanner.warnings": "Warnings",
      "scanner.recommendations": "Recommendations",
      "scanner.scanAgain": "Scan Again",
      "scanner.viewDetails": "View Details",
      "nutrition.info": "Nutrition Information (100g)",
      "nutrition.calories": "Calories",
      "nutrition.protein": "Protein",
      "nutrition.fat": "Fat",
      "nutrition.carbs": "Carbs",
      "nutrition.fiber": "Fiber",
      "nutrition.sugar": "Sugar",
      "nutrition.recommendation.vitaminC": "Good source of vitamin C",
      "nutrition.recommendation.fiber": "Rich in fiber",
      "nutrition.recommendation.eatWithSkin": "Eat with skin to maximize nutrition",
    },
    zh: {
      "app.title": "D 健康生活",
      "app.subtitle": "每天健康生活",
      "scanner.instruction": "拍照或扫描二维码分析食品",
      "scanner.openCamera": "打开相机",
      "scanner.uploadPhoto": "上传照片",
      "scanner.analyze": "分析",
      "scanner.analyzing": "正在分析食品...",
      "scanner.pleaseWait": "请稍等片刻",
      "scanner.safe": "安全",
      "scanner.warning": "警告",
      "scanner.warnings": "警告",
      "scanner.recommendations": "建议",
      "scanner.scanAgain": "重新扫描",
      "scanner.viewDetails": "查看详情",
      "nutrition.info": "营养信息 (100克)",
      "nutrition.calories": "卡路里",
      "nutrition.protein": "蛋白质",
      "nutrition.fat": "脂肪",
      "nutrition.carbs": "碳水化合物",
      "nutrition.fiber": "纤维",
      "nutrition.sugar": "糖",
      "nutrition.recommendation.vitaminC": "维生素C的良好来源",
      "nutrition.recommendation.fiber": "富含纤维",
      "nutrition.recommendation.eatWithSkin": "连皮食用以最大化营养",
    },
    ja: {
      "app.title": "D ヘルシーライフ",
      "app.subtitle": "毎日健康に生きる",
      "scanner.instruction": "写真を撮るかQRコードをスキャンして食品を分析",
      "scanner.openCamera": "カメラを開く",
      "scanner.uploadPhoto": "写真をアップロード",
      "scanner.analyze": "分析",
      "scanner.analyzing": "食品を分析中...",
      "scanner.pleaseWait": "しばらくお待ちください",
      "scanner.safe": "安全",
      "scanner.warning": "警告",
      "scanner.warnings": "警告",
      "scanner.recommendations": "推奨事項",
      "scanner.scanAgain": "再スキャン",
      "scanner.viewDetails": "詳細を見る",
      "nutrition.info": "栄養情報 (100g)",
      "nutrition.calories": "カロリー",
      "nutrition.protein": "タンパク質",
      "nutrition.fat": "脂肪",
      "nutrition.carbs": "炭水化物",
      "nutrition.fiber": "食物繊維",
      "nutrition.sugar": "糖",
      "nutrition.recommendation.vitaminC": "ビタミンCの良い供給源",
      "nutrition.recommendation.fiber": "食物繊維が豊富",
      "nutrition.recommendation.eatWithSkin": "皮ごと食べると栄養価が最大化",
    },
    ko: {
      "app.title": "D 건강한 생활",
      "app.subtitle": "매일 건강하게 살기",
      "scanner.instruction": "사진을 찍거나 QR 코드를 스캔하여 음식 분석",
      "scanner.openCamera": "카메라 열기",
      "scanner.uploadPhoto": "사진 업로드",
      "scanner.analyze": "분석",
      "scanner.analyzing": "음식 분석 중...",
      "scanner.pleaseWait": "잠시만 기다려주세요",
      "scanner.safe": "안전",
      "scanner.warning": "경고",
      "scanner.warnings": "경고",
      "scanner.recommendations": "권장 사항",
      "scanner.scanAgain": "다시 스캔",
      "scanner.viewDetails": "상세 보기",
      "nutrition.info": "영양 정보 (100g)",
      "nutrition.calories": "칼로리",
      "nutrition.protein": "단백질",
      "nutrition.fat": "지방",
      "nutrition.carbs": "탄수화물",
      "nutrition.fiber": "섬유질",
      "nutrition.sugar": "당",
      "nutrition.recommendation.vitaminC": "비타민 C의 좋은 공급원",
      "nutrition.recommendation.fiber": "섬유질이 풍부함",
      "nutrition.recommendation.eatWithSkin": "영양을 최대화하기 위해 껍질과 함께 먹기",
    },
    fr: {
      "app.title": "D Vie Saine",
      "app.subtitle": "Vivre Sainement Chaque Jour",
      "scanner.instruction": "Prenez une photo ou scannez un code QR pour analyser les aliments",
      "scanner.openCamera": "Ouvrir la Caméra",
      "scanner.uploadPhoto": "Télécharger une Photo",
      "scanner.analyze": "Analyser",
      "scanner.analyzing": "Analyse des aliments en cours...",
      "scanner.pleaseWait": "Veuillez patienter un moment",
      "scanner.safe": "Sûr",
      "scanner.warning": "Avertissement",
      "scanner.warnings": "Avertissements",
      "scanner.recommendations": "Recommandations",
      "scanner.scanAgain": "Scanner à Nouveau",
      "scanner.viewDetails": "Voir les Détails",
      "nutrition.info": "Informations Nutritionnelles (100g)",
      "nutrition.calories": "Calories",
      "nutrition.protein": "Protéines",
      "nutrition.fat": "Matières grasses",
      "nutrition.carbs": "Glucides",
      "nutrition.fiber": "Fibres",
      "nutrition.sugar": "Sucre",
      "nutrition.recommendation.vitaminC": "Bonne source de vitamine C",
      "nutrition.recommendation.fiber": "Riche en fibres",
      "nutrition.recommendation.eatWithSkin": "Manger avec la peau pour maximiser la nutrition",
    },
    de: {
      "app.title": "D Gesundes Leben",
      "app.subtitle": "Jeden Tag gesund leben",
      "scanner.instruction": "Machen Sie ein Foto oder scannen Sie einen QR-Code, um Lebensmittel zu analysieren",
      "scanner.openCamera": "Kamera öffnen",
      "scanner.uploadPhoto": "Foto hochladen",
      "scanner.analyze": "Analysieren",
      "scanner.analyzing": "Lebensmittel werden analysiert...",
      "scanner.pleaseWait": "Bitte warten Sie einen Moment",
      "scanner.safe": "Sicher",
      "scanner.warning": "Warnung",
      "scanner.warnings": "Warnungen",
      "scanner.recommendations": "Empfehlungen",
      "scanner.scanAgain": "Erneut scannen",
      "scanner.viewDetails": "Details anzeigen",
      "nutrition.info": "Nährwertinformationen (100g)",
      "nutrition.calories": "Kalorien",
      "nutrition.protein": "Protein",
      "nutrition.fat": "Fett",
      "nutrition.carbs": "Kohlenhydrate",
      "nutrition.fiber": "Ballaststoffe",
      "nutrition.sugar": "Zucker",
      "nutrition.recommendation.vitaminC": "Gute Quelle für Vitamin C",
      "nutrition.recommendation.fiber": "Reich an Ballaststoffen",
      "nutrition.recommendation.eatWithSkin": "Mit Schale essen, um die Nährstoffe zu maximieren",
    },
    es: {
      "app.title": "D Vida Saludable",
      "app.subtitle": "Vive Saludable Cada Día",
      "scanner.instruction": "Toma una foto o escanea un código QR para analizar alimentos",
      "scanner.openCamera": "Abrir Cámara",
      "scanner.uploadPhoto": "Subir Foto",
      "scanner.analyze": "Analizar",
      "scanner.analyzing": "Analizando alimentos...",
      "scanner.pleaseWait": "Por favor espere un momento",
      "scanner.safe": "Seguro",
      "scanner.warning": "Advertencia",
      "scanner.warnings": "Advertencias",
      "scanner.recommendations": "Recomendaciones",
      "scanner.scanAgain": "Escanear de Nuevo",
      "scanner.viewDetails": "Ver Detalles",
      "nutrition.info": "Información Nutricional (100g)",
      "nutrition.calories": "Calorías",
      "nutrition.protein": "Proteínas",
      "nutrition.fat": "Grasas",
      "nutrition.carbs": "Carbohidratos",
      "nutrition.fiber": "Fibra",
      "nutrition.sugar": "Azúcar",
      "nutrition.recommendation.vitaminC": "Buena fuente de vitamina C",
      "nutrition.recommendation.fiber": "Rico en fibra",
      "nutrition.recommendation.eatWithSkin": "Comer con piel para maximizar la nutrición",
    },
    ru: {
      "app.title": "D Здоровая Жизнь",
      "app.subtitle": "Живи Здорово Каждый День",
      "scanner.instruction": "Сделайте фото или отсканируйте QR-код для анализа пищи",
      "scanner.openCamera": "Открыть Камеру",
      "scanner.uploadPhoto": "Загрузить Фото",
      "scanner.analyze": "Анализировать",
      "scanner.analyzing": "Анализ пищи...",
      "scanner.pleaseWait": "Пожалуйста, подождите",
      "scanner.safe": "Безопасно",
      "scanner.warning": "Предупреждение",
      "scanner.warnings": "Предупреждения",
      "scanner.recommendations": "Рекомендации",
      "scanner.scanAgain": "Сканировать Снова",
      "scanner.viewDetails": "Подробнее",
      "nutrition.info": "Пищевая Ценность (100г)",
      "nutrition.calories": "Калории",
      "nutrition.protein": "Белки",
      "nutrition.fat": "Жиры",
      "nutrition.carbs": "Углеводы",
      "nutrition.fiber": "Клетчатка",
      "nutrition.sugar": "Сахар",
      "nutrition.recommendation.vitaminC": "Хороший источник витамина C",
      "nutrition.recommendation.fiber": "Богат клетчаткой",
      "nutrition.recommendation.eatWithSkin": "Ешьте с кожурой для максимальной пользы",
    },
    ar: {
      "app.title": "D حياة صحية",
      "app.subtitle": "عش بصحة كل يوم",
      "scanner.instruction": "التقط صورة أو امسح رمز QR لتحليل الطعام",
      "scanner.openCamera": "فتح الكاميرا",
      "scanner.uploadPhoto": "تحميل صورة",
      "scanner.analyze": "تحليل",
      "scanner.analyzing": "جاري تحليل الطعام...",
      "scanner.pleaseWait": "يرجى الانتظار لحظة",
      "scanner.safe": "آمن",
      "scanner.warning": "تحذير",
      "scanner.warnings": "تحذيرات",
      "scanner.recommendations": "توصيات",
      "scanner.scanAgain": "مسح مرة أخرى",
      "scanner.viewDetails": "عرض التفاصيل",
      "nutrition.info": "معلومات غذائية (100 جرام)",
      "nutrition.calories": "سعرات حرارية",
      "nutrition.protein": "بروتين",
      "nutrition.fat": "دهون",
      "nutrition.carbs": "كربوهيدرات",
      "nutrition.fiber": "ألياف",
      "nutrition.sugar": "سكر",
      "nutrition.recommendation.vitaminC": "مصدر جيد لفيتامين C",
      "nutrition.recommendation.fiber": "غني بالألياف",
      "nutrition.recommendation.eatWithSkin": "تناول مع القشرة لتعظيم القيمة الغذائية",
    },
    th: {
      "app.title": "D ชีวิตสุขภาพดี",
      "app.subtitle": "ใช้ชีวิตอย่างมีสุขภาพดีทุกวัน",
      "scanner.instruction": "ถ่ายภาพหรือสแกน QR โค้ดเพื่อวิเคราะห์อาหาร",
      "scanner.openCamera": "เปิดกล้อง",
      "scanner.uploadPhoto": "อัปโหลดรูปภาพ",
      "scanner.analyze": "วิเคราะห์",
      "scanner.analyzing": "กำลังวิเคราะห์อาหาร...",
      "scanner.pleaseWait": "กรุณารอสักครู่",
      "scanner.safe": "ปลอดภัย",
      "scanner.warning": "คำเตือน",
      "scanner.warnings": "คำเตือน",
      "scanner.recommendations": "คำแนะนำ",
      "scanner.scanAgain": "สแกนอีกครั้ง",
      "scanner.viewDetails": "ดูรายละเอียด",
      "nutrition.info": "ข้อมูลโภชนาการ (100 กรัม)",
      "nutrition.calories": "แคลอรี่",
      "nutrition.protein": "โปรตีน",
      "nutrition.fat": "ไขมัน",
      "nutrition.carbs": "คาร์โบไฮเดรต",
      "nutrition.fiber": "ใยอาหาร",
      "nutrition.sugar": "น้ำตาล",
      "nutrition.recommendation.vitaminC": "แหล่งวิตามินซีที่ดี",
      "nutrition.recommendation.fiber": "อุดมไปด้วยใยอาหาร",
      "nutrition.recommendation.eatWithSkin": "รับประทานพร้อมเปลือกเพื่อคุณค่าทางโภชนาการสูงสุด",
    },
  }

  return translations[language] || translations["en"]
}

