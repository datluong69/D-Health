"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Loader2, Search } from "lucide-react"
import { useTranslation } from "@/hooks/use-translation"

interface AIResponse {
  nutritionAnalysis: string
  healthRecommendations: string[]
  possibleAllergies: string[]
}

export default function AIFoodAnalyzer() {
  const { t } = useTranslation()
  const [query, setQuery] = useState("")
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [result, setResult] = useState<AIResponse | null>(null)

  const handleAnalyze = () => {
    if (!query.trim()) return

    setIsAnalyzing(true)
    setResult(null)

    // Simulate AI analysis
    setTimeout(() => {
      // Mock AI response
      const mockResponse: AIResponse = {
        nutritionAnalysis:
          "Bữa ăn của bạn có khoảng 650 calories, 25g protein, 30g chất béo, và 70g carbohydrate. Lượng natri hơi cao (khoảng 800mg) và lượng chất xơ thấp (chỉ 5g).",
        healthRecommendations: [
          "Thêm rau xanh để tăng lượng chất xơ",
          "Giảm lượng muối trong chế biến để hạn chế natri",
          "Cân nhắc thay thế tinh bột trắng bằng ngũ cốc nguyên hạt",
          "Bổ sung thêm protein từ thực vật như đậu hoặc hạt",
        ],
        possibleAllergies: [
          "Món ăn có thể chứa gluten",
          "Có thành phần từ sữa, không phù hợp cho người không dung nạp lactose",
        ],
      }

      setResult(mockResponse)
      setIsAnalyzing(false)
    }, 2000)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Search className="mr-2 h-5 w-5 text-green-600" />
          Trợ Lý AI Phân Tích Thực Phẩm
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Textarea
            placeholder="Mô tả bữa ăn của bạn (ví dụ: Bữa trưa gồm cơm trắng, thịt gà kho, canh rau cải, 1 quả chuối)..."
            className="min-h-[100px]"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        <Button
          onClick={handleAnalyze}
          className="w-full bg-green-600 hover:bg-green-700"
          disabled={isAnalyzing || !query.trim()}
        >
          {isAnalyzing ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Đang phân tích...
            </>
          ) : (
            "Phân tích dinh dưỡng"
          )}
        </Button>

        {result && (
          <div className="mt-6 space-y-4">
            <div>
              <h3 className="font-medium text-lg">Phân tích dinh dưỡng:</h3>
              <p className="mt-1 text-gray-700">{result.nutritionAnalysis}</p>
            </div>

            <div>
              <h3 className="font-medium text-lg">Khuyến nghị sức khỏe:</h3>
              <ul className="mt-1 list-disc list-inside space-y-1">
                {result.healthRecommendations.map((rec, index) => (
                  <li key={index} className="text-gray-700">
                    {rec}
                  </li>
                ))}
              </ul>
            </div>

            {result.possibleAllergies.length > 0 && (
              <div>
                <h3 className="font-medium text-lg text-amber-600">Cảnh báo dị ứng tiềm ẩn:</h3>
                <ul className="mt-1 list-disc list-inside space-y-1">
                  {result.possibleAllergies.map((allergy, index) => (
                    <li key={index} className="text-amber-600">
                      {allergy}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

