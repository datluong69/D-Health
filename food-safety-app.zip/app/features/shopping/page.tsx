import Navigation from "@/components/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ShoppingBag, Search, Filter, MapPin, Star, Clock, ShoppingCart } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"

export default function ShoppingPage() {
  return (
    <main className="flex min-h-screen flex-col bg-gradient-to-b from-green-50 to-sky-50">
      <Navigation />

      <div className="container px-4 py-6 mx-auto">
        <div className="flex items-center mb-6">
          <ShoppingBag className="h-8 w-8 text-green-600 mr-3" />
          <h1 className="text-3xl font-bold text-green-600">Kết Nối Siêu Thị</h1>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Tìm Kiếm Thực Phẩm Sạch</CardTitle>
                <CardDescription>Kết nối với các siêu thị và cửa hàng thực phẩm sạch gần bạn</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row gap-4">
                    <div className="relative flex-1">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                      <Input placeholder="Tìm kiếm thực phẩm hoặc cửa hàng..." className="pl-10" />
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" className="flex items-center">
                        <MapPin className="h-4 w-4 mr-2" />
                        Gần tôi
                      </Button>
                      <Button variant="outline" className="flex items-center">
                        <Filter className="h-4 w-4 mr-2" />
                        Bộ lọc
                      </Button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                    <StoreCard
                      name="Organic Food Market"
                      image="/placeholder.svg?height=100&width=100"
                      rating={4.8}
                      distance="1.2 km"
                      address="123 Nguyễn Văn Linh, Quận 7"
                      categories={["Hữu cơ", "Rau củ", "Trái cây"]}
                    />
                    <StoreCard
                      name="Fresh & Green"
                      image="/placeholder.svg?height=100&width=100"
                      rating={4.6}
                      distance="2.5 km"
                      address="456 Lê Văn Lương, Quận 7"
                      categories={["Thực phẩm sạch", "Đồ tươi", "Hải sản"]}
                    />
                    <StoreCard
                      name="VinMart Organic"
                      image="/placeholder.svg?height=100&width=100"
                      rating={4.5}
                      distance="3.1 km"
                      address="789 Nguyễn Hữu Thọ, Quận 7"
                      categories={["Siêu thị", "Hữu cơ", "Đa dạng"]}
                    />
                    <StoreCard
                      name="Farmers' Market"
                      image="/placeholder.svg?height=100&width=100"
                      rating={4.7}
                      distance="4.3 km"
                      address="101 Nguyễn Thị Thập, Quận 7"
                      categories={["Chợ nông sản", "Trực tiếp từ nông dân"]}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Giỏ Hàng Thông Minh</CardTitle>
                <CardDescription>Đề xuất thực phẩm dựa trên phân tích dinh dưỡng và mục tiêu sức khỏe</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-medium">Đề xuất cho bạn</h3>
                    <Button variant="link" className="text-green-600 p-0">
                      Xem tất cả
                    </Button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                    <ProductCard
                      name="Rau cải xanh hữu cơ"
                      image="/placeholder.svg?height=100&width=100"
                      price={35000}
                      unit="500g"
                      store="Organic Food Market"
                      rating={4.8}
                      reason="Giàu vitamin K và chất xơ"
                    />
                    <ProductCard
                      name="Cá hồi tươi"
                      image="/placeholder.svg?height=100&width=100"
                      price={220000}
                      unit="300g"
                      store="Fresh & Green"
                      rating={4.7}
                      reason="Bổ sung Omega-3 cho chế độ ăn"
                    />
                    <ProductCard
                      name="Quả óc chó"
                      image="/placeholder.svg?height=100&width=100"
                      price={120000}
                      unit="200g"
                      store="VinMart Organic"
                      rating={4.6}
                      reason="Tốt cho sức khỏe não bộ"
                    />
                  </div>

                  <div className="flex justify-center mt-4">
                    <Button className="bg-green-600 hover:bg-green-700">
                      <ShoppingCart className="mr-2 h-4 w-4" />
                      Xem giỏ hàng của tôi
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Đối Tác Của Chúng Tôi</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center mr-3">
                        <img
                          src="/placeholder.svg?height=40&width=40"
                          alt="VinMart"
                          className="w-8 h-8 object-contain"
                        />
                      </div>
                      <div>
                        <h3 className="font-medium text-sm">VinMart</h3>
                        <p className="text-xs text-gray-500">150+ cửa hàng</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">
                      Xem
                    </Button>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center mr-3">
                        <img
                          src="/placeholder.svg?height=40&width=40"
                          alt="Co.op Mart"
                          className="w-8 h-8 object-contain"
                        />
                      </div>
                      <div>
                        <h3 className="font-medium text-sm">Co.op Mart</h3>
                        <p className="text-xs text-gray-500">120+ cửa hàng</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">
                      Xem
                    </Button>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center mr-3">
                        <img
                          src="/placeholder.svg?height=40&width=40"
                          alt="Organic Food"
                          className="w-8 h-8 object-contain"
                        />
                      </div>
                      <div>
                        <h3 className="font-medium text-sm">Organic Food</h3>
                        <p className="text-xs text-gray-500">50+ cửa hàng</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">
                      Xem
                    </Button>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center mr-3">
                        <img
                          src="/placeholder.svg?height=40&width=40"
                          alt="Farmers Market"
                          className="w-8 h-8 object-contain"
                        />
                      </div>
                      <div>
                        <h3 className="font-medium text-sm">Farmers Market</h3>
                        <p className="text-xs text-gray-500">30+ chợ</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">
                      Xem
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Lợi Ích</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start">
                    <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center mr-3 flex-shrink-0">
                      <span className="text-green-600 font-medium">1</span>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium">Đảm bảo nguồn gốc</h3>
                      <p className="text-sm text-gray-600 mt-1">
                        Tất cả sản phẩm đều được xác minh nguồn gốc và đảm bảo chất lượng.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center mr-3 flex-shrink-0">
                      <span className="text-green-600 font-medium">2</span>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium">Giao hàng nhanh chóng</h3>
                      <p className="text-sm text-gray-600 mt-1">
                        Giao hàng trong vòng 2 giờ đối với khu vực nội thành.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center mr-3 flex-shrink-0">
                      <span className="text-green-600 font-medium">3</span>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium">Đề xuất thông minh</h3>
                      <p className="text-sm text-gray-600 mt-1">
                        Đề xuất thực phẩm dựa trên mục tiêu sức khỏe và chế độ ăn uống của bạn.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center mr-3 flex-shrink-0">
                      <span className="text-green-600 font-medium">4</span>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium">Ưu đãi độc quyền</h3>
                      <p className="text-sm text-gray-600 mt-1">
                        Nhận ưu đãi và khuyến mãi độc quyền từ các đối tác của chúng tôi.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </main>
  )
}

interface StoreCardProps {
  name: string
  image: string
  rating: number
  distance: string
  address: string
  categories: string[]
}

function StoreCard({ name, image, rating, distance, address, categories }: StoreCardProps) {
  return (
    <div className="border rounded-lg p-4 bg-white hover:shadow-md transition-shadow">
      <div className="flex">
        <img src={image || "/placeholder.svg"} alt={name} className="w-16 h-16 object-cover rounded-md mr-3" />
        <div className="flex-1">
          <div className="flex justify-between items-start">
            <h3 className="font-medium">{name}</h3>
            <div className="flex items-center">
              <Star className="h-3 w-3 text-yellow-500 mr-1" />
              <span className="text-sm">{rating}</span>
            </div>
          </div>
          <div className="flex items-center text-xs text-gray-500 mt-1">
            <MapPin className="h-3 w-3 mr-1" />
            <span>{distance}</span>
            <span className="mx-1">•</span>
            <Clock className="h-3 w-3 mr-1" />
            <span>Mở cửa</span>
          </div>
          <p className="text-xs text-gray-500 mt-1">{address}</p>
          <div className="flex flex-wrap gap-1 mt-2">
            {categories.map((category, index) => (
              <Badge key={index} variant="outline" className="text-xs bg-green-50 text-green-700 border-green-200">
                {category}
              </Badge>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

interface ProductCardProps {
  name: string
  image: string
  price: number
  unit: string
  store: string
  rating: number
  reason: string
}

function ProductCard({ name, image, price, unit, store, rating, reason }: ProductCardProps) {
  return (
    <div className="border rounded-lg overflow-hidden bg-white hover:shadow-md transition-shadow">
      <div className="relative">
        <img src={image || "/placeholder.svg"} alt={name} className="w-full h-32 object-cover" />
        <div className="absolute top-2 right-2 bg-white rounded-full px-2 py-1 flex items-center text-xs">
          <Star className="h-3 w-3 text-yellow-500 mr-1" />
          <span>{rating}</span>
        </div>
      </div>
      <div className="p-3">
        <h3 className="font-medium text-sm">{name}</h3>
        <div className="flex justify-between items-center mt-1">
          <div className="text-green-600 font-medium">{price.toLocaleString()}đ</div>
          <div className="text-xs text-gray-500">/{unit}</div>
        </div>
        <div className="text-xs text-gray-500 mt-1">{store}</div>
        <div className="mt-2 bg-green-50 text-green-700 text-xs p-1 rounded">
          <span className="font-medium">Đề xuất:</span> {reason}
        </div>
        <Button className="w-full mt-2 bg-green-600 hover:bg-green-700 h-8 text-xs">Thêm vào giỏ hàng</Button>
      </div>
    </div>
  )
}

