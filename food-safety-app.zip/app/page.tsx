import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import {
  ArrowRight,
  Camera,
  Leaf,
  ShieldCheck,
  Utensils,
  ShoppingBag,
  Calendar,
  AlertTriangle,
  Pill,
  Download,
  Smartphone,
  Globe,
} from "lucide-react"
import Navigation from "@/components/navigation"
import FoodScanner from "@/components/food-scanner"
import HealthMetrics from "@/components/health-metrics"
import FoodSafetyMap from "@/components/food-safety-map"
import ChatAssistant from "@/components/chat-assistant"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col bg-gradient-to-b from-green-50 to-sky-50">
      <Navigation />

      <div className="container px-4 py-6 mx-auto">
        <section className="mb-10">
          <div className="flex flex-col md:flex-row gap-6 items-center">
            <div className="flex-1">
              <h1 className="text-4xl font-bold text-green-600 mb-4">Sống Khỏe Mỗi Ngày</h1>
              <p className="text-lg mb-6 text-gray-700">
                Kiểm tra chất lượng, phân tích dinh dưỡng và đảm bảo an toàn thực phẩm với công nghệ AI tiên tiến.
              </p>
              <div className="flex gap-4">
                <Button className="bg-green-600 hover:bg-green-700" asChild>
                  <Link href="/scan">
                    <Camera className="mr-2 h-4 w-4" />
                    Quét Thực Phẩm
                  </Link>
                </Button>
                <Button variant="outline" className="border-sky-500 text-sky-600 hover:bg-sky-50">
                  Tìm Hiểu Thêm
                </Button>
              </div>
            </div>
            <div className="flex-1">
              <FoodScanner />
            </div>
          </div>
        </section>

        <section className="mb-10">
          <h2 className="text-2xl font-bold mb-6 text-green-600">Chỉ Số Sức Khỏe</h2>
          <HealthMetrics />
        </section>

        <section className="mb-10">
          <h2 className="text-2xl font-bold mb-6 text-green-600">Bản Đồ An Toàn Thực Phẩm</h2>
          <FoodSafetyMap />
        </section>

        <section className="mb-10">
          <h2 className="text-2xl font-bold mb-6 text-green-600">Trợ Lý Thông Minh</h2>
          <ChatAssistant />
        </section>

        <section className="mb-10">
          <h2 className="text-2xl font-bold mb-6 text-green-600">Tính Năng Nổi Bật</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-2">
                  <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mb-4">
                    {feature.icon}
                  </div>
                  <CardTitle className="text-lg">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>{feature.description}</CardDescription>
                </CardContent>
                <CardFooter>
                  <Link href={feature.link} className="text-green-600 hover:text-green-700 text-sm flex items-center">
                    Xem chi tiết <ArrowRight className="ml-1 h-4 w-4" />
                  </Link>
                </CardFooter>
              </Card>
            ))}
          </div>
        </section>

        <section className="mb-10">
          <h2 className="text-2xl font-bold mb-6 text-green-600">Tải Ứng Dụng</h2>
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row items-center gap-6">
                <div className="flex-1">
                  <h3 className="text-xl font-bold mb-4">Tải D Healthy Life cho thiết bị di động</h3>
                  <p className="text-gray-700 mb-6">
                    Tải ứng dụng D Healthy Life để trải nghiệm đầy đủ các tính năng, bao gồm quét thực phẩm ngoại tuyến,
                    theo dõi chế độ ăn uống, và nhận thông báo về an toàn thực phẩm.
                  </p>
                  <div className="flex flex-wrap gap-4">
                    <Button className="bg-black text-white hover:bg-gray-800">
                      <Download className="mr-2 h-4 w-4" />
                      Tải cho iOS
                    </Button>
                    <Button className="bg-green-600 hover:bg-green-700">
                      <Download className="mr-2 h-4 w-4" />
                      Tải cho Android
                    </Button>
                    <Button variant="outline">
                      <Globe className="mr-2 h-4 w-4" />
                      Phiên bản Web
                    </Button>
                  </div>
                </div>
                <div className="flex-shrink-0">
                  <div className="relative w-[200px] h-[400px] bg-gray-200 rounded-3xl overflow-hidden border-8 border-gray-800">
                    <div className="absolute top-0 left-0 right-0 h-6 bg-gray-800 rounded-t-xl"></div>
                    <div className="absolute bottom-0 left-0 right-0 h-10 bg-gray-800 rounded-b-xl flex justify-center items-center">
                      <div className="w-16 h-1 bg-gray-600 rounded-full"></div>
                    </div>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Smartphone className="h-16 w-16 text-gray-400" />
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>
      </div>
    </main>
  )
}

const features = [
  {
    title: "Kiểm Tra Chất Lượng",
    description: "Phát hiện dư lượng thuốc trừ sâu, chất bảo quản độc hại và nhận diện thực phẩm giả.",
    icon: <ShieldCheck className="h-6 w-6 text-green-600" />,
    link: "/features/quality",
  },
  {
    title: "Phân Tích Dinh Dưỡng",
    description: "Chụp ảnh và phân tích hàm lượng calo, đạm, béo, đường, vitamin, khoáng chất.",
    icon: <Utensils className="h-6 w-6 text-green-600" />,
    link: "/features/nutrition",
  },
  {
    title: "Kết Nối Siêu Thị",
    description: "Tích hợp với siêu thị và cửa hàng thực phẩm sạch để mua hàng ngay trên app.",
    icon: <ShoppingBag className="h-6 w-6 text-green-600" />,
    link: "/features/shopping",
  },
  {
    title: "Quản Lý Hạn Sử Dụng",
    description: "Phát hiện thực phẩm hết hạn và lên kế hoạch tiêu thụ thực phẩm hiệu quả.",
    icon: <Calendar className="h-6 w-6 text-green-600" />,
    link: "/features/expiration",
  },
  {
    title: "Cảnh Báo Dịch Bệnh",
    description: "Theo dõi và cảnh báo các đợt bùng phát dịch bệnh liên quan đến thực phẩm.",
    icon: <AlertTriangle className="h-6 w-6 text-green-600" />,
    link: "/features/alerts",
  },
  {
    title: "Tương Tác Thuốc",
    description: "Cảnh báo thực phẩm kỵ thuốc và gợi ý thực phẩm hỗ trợ điều trị bệnh.",
    icon: <Pill className="h-6 w-6 text-green-600" />,
    link: "/features/medication",
  },
  {
    title: "Chế Độ Ăn Cá Nhân",
    description: "Tạo thực đơn thông minh dựa trên mục tiêu cá nhân và nhu cầu sức khỏe.",
    icon: <Leaf className="h-6 w-6 text-green-600" />,
    link: "/features/diet",
  },
  {
    title: "Xác Minh Nguồn Gốc",
    description: "Xác minh nguồn gốc thực phẩm bằng blockchain, biết chính xác thực phẩm đến từ đâu.",
    icon: <ShieldCheck className="h-6 w-6 text-green-600" />,
    link: "/features/origin",
  },
]

