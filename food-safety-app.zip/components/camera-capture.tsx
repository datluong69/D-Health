"use client"

import { useState } from "react"
import { useCamera } from "@/hooks/use-camera"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Camera, CameraIcon as FlipCamera, X, Check } from "lucide-react"

interface CameraCaptureProps {
  onCapture: (imageBlob: Blob) => void
  onCancel: () => void
}

export default function CameraCapture({ onCapture, onCancel }: CameraCaptureProps) {
  const [capturedImage, setCapturedImage] = useState<string | null>(null)

  const handlePhotoCapture = (blob: Blob) => {
    const imageUrl = URL.createObjectURL(blob)
    setCapturedImage(imageUrl)
  }

  const { videoRef, canvasRef, isActive, hasPermission, error, startCamera, stopCamera, switchCamera, takePhoto } =
    useCamera({
      onPhotoCapture: handlePhotoCapture,
    })

  const handleCapture = () => {
    takePhoto()
  }

  const handleRetake = () => {
    setCapturedImage(null)
  }

  const handleConfirm = () => {
    if (capturedImage) {
      fetch(capturedImage)
        .then((res) => res.blob())
        .then((blob) => {
          onCapture(blob)
        })
    }
  }

  return (
    <Card className="w-full overflow-hidden">
      <CardContent className="p-0">
        <div className="relative aspect-video bg-gray-100">
          {!isActive && !capturedImage && (
            <div className="absolute inset-0 flex flex-col items-center justify-center p-4">
              {error ? (
                <div className="text-center text-red-500 mb-4">{error}</div>
              ) : (
                <p className="text-center text-gray-500 mb-4">Cho phép truy cập camera để chụp ảnh thực phẩm</p>
              )}
              <Button onClick={startCamera} className="bg-green-600 hover:bg-green-700">
                <Camera className="mr-2 h-4 w-4" />
                Mở Camera
              </Button>
            </div>
          )}

          {isActive && !capturedImage && (
            <>
              <video ref={videoRef} autoPlay playsInline className="absolute inset-0 w-full h-full object-cover" />
              <div className="absolute bottom-4 left-0 right-0 flex justify-center space-x-4">
                <Button variant="outline" size="icon" className="bg-white" onClick={onCancel}>
                  <X className="h-5 w-5" />
                </Button>
                <Button
                  size="icon"
                  className="bg-white text-black hover:bg-gray-100 h-14 w-14 rounded-full"
                  onClick={handleCapture}
                >
                  <div className="h-10 w-10 rounded-full border-2 border-black"></div>
                </Button>
                <Button variant="outline" size="icon" className="bg-white" onClick={switchCamera}>
                  <FlipCamera className="h-5 w-5" />
                </Button>
              </div>
            </>
          )}

          {capturedImage && (
            <>
              <img
                src={capturedImage || "/placeholder.svg"}
                alt="Captured food"
                className="absolute inset-0 w-full h-full object-cover"
              />
              <div className="absolute bottom-4 left-0 right-0 flex justify-center space-x-4">
                <Button variant="outline" size="icon" className="bg-white" onClick={handleRetake}>
                  <X className="h-5 w-5" />
                </Button>
                <Button
                  size="icon"
                  className="bg-green-600 hover:bg-green-700 h-14 w-14 rounded-full"
                  onClick={handleConfirm}
                >
                  <Check className="h-6 w-6" />
                </Button>
              </div>
            </>
          )}

          {/* Hidden canvas for capturing images */}
          <canvas ref={canvasRef} className="hidden" />
        </div>
      </CardContent>
    </Card>
  )
}

