"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Smartphone, Laptop, Server, AlertTriangle, CheckCircle2 } from "lucide-react"

export default function AppExportGuide() {
  const [activeTab, setActiveTab] = useState("mobile")

  return (
    <Card>
      <CardHeader>
        <CardTitle>Hướng Dẫn Xuất Ứng Dụng</CardTitle>
        <CardDescription>Chuyển đổi ứng dụng web D Healthy Life thành ứng dụng di động hoặc máy tính</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="mobile" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="mobile">
              <Smartphone className="h-4 w-4 mr-2" />
              Ứng dụng di động
            </TabsTrigger>
            <TabsTrigger value="desktop">
              <Laptop className="h-4 w-4 mr-2" />
              Ứng dụng máy tính
            </TabsTrigger>
            <TabsTrigger value="pwa">
              <Server className="h-4 w-4 mr-2" />
              Progressive Web App
            </TabsTrigger>
          </TabsList>

          <TabsContent value="mobile">
            <div className="space-y-4">
              <h3 className="text-lg font-medium">Xuất ứng dụng di động với React Native</h3>
              <p className="text-gray-700">
                Để chuyển đổi ứng dụng web hiện tại thành ứng dụng di động, chúng tôi sẽ sử dụng React Native và tái sử
                dụng phần lớn logic nghiệp vụ.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                <div className="border rounded-lg p-4">
                  <h4 className="font-medium mb-2 flex items-center">
                    <CheckCircle2 className="h-4 w-4 mr-2 text-green-600" />
                    Ưu điểm
                  </h4>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    <li>Truy cập đầy đủ các tính năng của thiết bị (camera, thông báo đẩy)</li>
                    <li>Hiệu suất tốt hơn và trải nghiệm người dùng mượt mà</li>
                    <li>Có thể phân phối qua App Store và Google Play</li>
                    <li>Hoạt động ngoại tuyến và đồng bộ hóa khi có kết nối</li>
                  </ul>
                </div>

                <div className="border rounded-lg p-4">
                  <h4 className="font-medium mb-2 flex items-center">
                    <AlertTriangle className="h-4 w-4 mr-2 text-amber-600" />
                    Thách thức
                  </h4>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    <li>Cần viết lại giao diện người dùng với React Native</li>
                    <li>Phải duy trì hai codebase riêng biệt (web và mobile)</li>
                    <li>Thời gian phát triển dài hơn</li>
                    <li>Chi phí phát triển và bảo trì cao hơn</li>
                  </ul>
                </div>
              </div>

              <Alert className="mt-4">
                <AlertTitle>Yêu cầu kỹ thuật</AlertTitle>
                <AlertDescription>
                  Để phát triển ứng dụng di động, bạn cần cài đặt React Native CLI, Android Studio (cho Android), Xcode
                  (cho iOS), và các công cụ phát triển liên quan.
                </AlertDescription>
              </Alert>

              <Button className="mt-4 bg-green-600 hover:bg-green-700">Tải hướng dẫn chi tiết</Button>
            </div>
          </TabsContent>

          <TabsContent value="desktop">
            <div className="space-y-4">
              <h3 className="text-lg font-medium">Xuất ứng dụng máy tính với Electron</h3>
              <p className="text-gray-700">
                Electron cho phép đóng gói ứng dụng web thành ứng dụng máy tính cho Windows, macOS và Linux với ít thay
                đổi.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                <div className="border rounded-lg p-4">
                  <h4 className="font-medium mb-2 flex items-center">
                    <CheckCircle2 className="h-4 w-4 mr-2 text-green-600" />
                    Ưu điểm
                  </h4>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    <li>Tái sử dụng hầu hết mã nguồn web hiện có</li>
                    <li>Truy cập vào các API hệ thống (tệp tin, thông báo)</li>
                    <li>Phân phối qua các cửa hàng ứng dụng máy tính</li>
                    <li>Cập nhật tự động và tích hợp với hệ điều hành</li>
                  </ul>
                </div>

                <div className="border rounded-lg p-4">
                  <h4 className="font-medium mb-2 flex items-center">
                    <AlertTriangle className="h-4 w-4 mr-2 text-amber-600" />
                    Thách thức
                  </h4>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    <li>Kích thước ứng dụng lớn do bao gồm Chromium</li>
                    <li>Tiêu thụ nhiều tài nguyên hệ thống hơn</li>
                    <li>Cần điều chỉnh giao diện cho trải nghiệm máy tính</li>
                    <li>Cấu hình bảo mật và quyền truy cập phức tạp hơn</li>
                  </ul>
                </div>
              </div>

              <Alert className="mt-4">
                <AlertTitle>Các bước cơ bản</AlertTitle>
                <AlertDescription>
                  1. Cài đặt Electron và electron-builder
                  <br />
                  2. Tạo main.js để khởi tạo cửa sổ ứng dụng
                  <br />
                  3. Cấu hình package.json với các script build
                  <br />
                  4. Đóng gói và phân phối ứng dụng
                </AlertDescription>
              </Alert>

              <Button className="mt-4 bg-green-600 hover:bg-green-700">Xem hướng dẫn từng bước</Button>
            </div>
          </TabsContent>

          <TabsContent value="pwa">
            <div className="space-y-4">
              <h3 className="text-lg font-medium">Chuyển đổi thành Progressive Web App (PWA)</h3>
              <p className="text-gray-700">
                PWA là giải pháp trung gian giữa web và ứng dụng di động, cho phép cài đặt từ trình duyệt và hoạt động
                ngoại tuyến.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                <div className="border rounded-lg p-4">
                  <h4 className="font-medium mb-2 flex items-center">
                    <CheckCircle2 className="h-4 w-4 mr-2 text-green-600" />
                    Ưu điểm
                  </h4>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    <li>Phát triển nhanh với codebase hiện tại</li>
                    <li>Không cần phê duyệt từ cửa hàng ứng dụng</li>
                    <li>Cập nhật tức thì không cần cài đặt lại</li>
                    <li>Hoạt động trên mọi nền tảng có trình duyệt hiện đại</li>
                  </ul>
                </div>

                <div className="border rounded-lg p-4">
                  <h4 className="font-medium mb-2 flex items-center">
                    <AlertTriangle className="h-4 w-4 mr-2 text-amber-600" />
                    Hạn chế
                  </h4>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    <li>Truy cập hạn chế vào tính năng thiết bị</li>
                    <li>Trải nghiệm người dùng không mượt mà bằng ứng dụng native</li>
                    <li>Khó khăn trong việc khám phá (không có cửa hàng ứng dụng)</li>
                    <li>Hỗ trợ không đồng đều giữa các trình duyệt</li>
                  </ul>
                </div>
              </div>

              <Alert className="mt-4 bg-green-50 border-green-200">
                <CheckCircle2 className="h-4 w-4 text-green-600" />
                <AlertTitle>Dễ dàng triển khai</AlertTitle>
                <AlertDescription>
                  Next.js đã hỗ trợ PWA thông qua next-pwa. Chỉ cần thêm manifest.json, service worker, và một số cấu
                  hình đơn giản là có thể chuyển đổi ứng dụng hiện tại thành PWA.
                </AlertDescription>
              </Alert>

              <Button className="mt-4 bg-green-600 hover:bg-green-700">Chuyển đổi thành PWA ngay</Button>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

