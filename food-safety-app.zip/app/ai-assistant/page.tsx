import Navigation from "@/components/navigation"
import AIFoodAnalyzer from "@/components/ai-food-analyzer"

export default function AIAssistantPage() {
  return (
    <main className="flex min-h-screen flex-col bg-gradient-to-b from-green-50 to-sky-50">
      <Navigation />

      <div className="container px-4 py-6 mx-auto">
        <h1 className="text-3xl font-bold text-green-600 mb-6">Trợ Lý AI</h1>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <AIFoodAnalyzer />
          </div>

          <div className="space-y-6">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h2 className="text-xl font-semibold mb-4">Trợ lý AI có thể giúp gì cho bạn?</h2>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <span className="flex-shrink-0 h-6 w-6 rounded-full bg-green-100 flex items-center justify-center text-green-600 mr-2">
                    1
                  </span>
                  <span>Phân tích thành phần dinh dưỡng trong bữa ăn của bạn</span>
                </li>
                <li className="flex items-start">
                  <span className="flex-shrink-0 h-6 w-6 rounded-full bg-green-100 flex items-center justify-center text-green-600 mr-2">
                    2
                  </span>
                  <span>Đưa ra khuyến nghị cải thiện chế độ ăn uống</span>
                </li>
                <li className="flex items-start">
                  <span className="flex-shrink-0 h-6 w-6 rounded-full bg-green-100 flex items-center justify-center text-green-600 mr-2">
                    3
                  </span>
                  <span>Cảnh báo về các dị ứng thực phẩm tiềm ẩn</span>
                </li>
                <li className="flex items-start">
                  <span className="flex-shrink-0 h-6 w-6 rounded-full bg-green-100 flex items-center justify-center text-green-600 mr-2">
                    4
                  </span>
                  <span>Gợi ý thực đơn phù hợp với mục tiêu sức khỏe của bạn</span>
                </li>
                <li className="flex items-start">
                  <span className="flex-shrink-0 h-6 w-6 rounded-full bg-green-100 flex items-center justify-center text-green-600 mr-2">
                    5
                  </span>
                  <span>Trả lời các câu hỏi về dinh dưỡng và an toàn thực phẩm</span>
                </li>
              </ul>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h2 className="text-xl font-semibold mb-4">Cách sử dụng hiệu quả</h2>
              <p className="text-gray-700 mb-4">
                Để nhận được phân tích chính xác nhất, hãy mô tả chi tiết bữa ăn của bạn bao gồm:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-700">
                <li>Loại thực phẩm (gạo, mì, thịt, rau...)</li>
                <li>Phương pháp chế biến (luộc, hấp, chiên, xào...)</li>
                <li>Khẩu phần ước tính (100g, 1 bát, 1 đĩa...)</li>
                <li>Các gia vị chính được sử dụng</li>
                <li>Thời điểm ăn trong ngày</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}

