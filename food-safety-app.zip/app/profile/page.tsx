import Navigation from "@/components/navigation"
import UserProfileForm from "@/components/user-profile-form"

export default function ProfilePage() {
  return (
    <main className="flex min-h-screen flex-col bg-gradient-to-b from-green-50 to-sky-50">
      <Navigation />

      <div className="container px-4 py-6 mx-auto">
        <h1 className="text-3xl font-bold text-green-600 mb-6">Hồ Sơ Cá Nhân</h1>

        <UserProfileForm />
      </div>
    </main>
  )
}

