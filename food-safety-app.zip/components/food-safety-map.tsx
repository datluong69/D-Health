"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MapPin, AlertTriangle, ThermometerSun, Wind } from "lucide-react"

export default function FoodSafetyMap() {
  const [activeTab, setActiveTab] = useState("map")

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle>Bản Đồ An Toàn Thực Phẩm & Điều Kiện Môi Trường</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="map" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="map">Bản Đồ An Toàn</TabsTrigger>
            <TabsTrigger value="environment">Điều Kiện Môi Trường</TabsTrigger>
          </TabsList>

          <TabsContent value="map" className="space-y-4">
            <div className="relative w-full h-80 bg-gray-100 rounded-lg overflow-hidden">
              {/* Placeholder for map */}
              <div className="absolute inset-0 bg-gray-200 flex items-center justify-center">
                <p className="text-gray-500">Bản đồ an toàn thực phẩm</p>
              </div>

              {/* Map markers */}
              <div className="absolute top-1/4 left-1/4 transform -translate-x-1/2 -translate-y-1/2">
                <MapMarker color="green" />
              </div>
              <div className="absolute top-1/3 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                <MapMarker color="green" />
              </div>
              <div className="absolute top-2/3 left-1/3 transform -translate-x-1/2 -translate-y-1/2">
                <MapMarker color="yellow" />
              </div>
              <div className="absolute top-1/2 left-3/4 transform -translate-x-1/2 -translate-y-1/2">
                <MapMarker color="red" />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <AlertCard
                title="Cảnh Báo Cao"
                count={2}
                description="Khu vực có nguy cơ cao về an toàn thực phẩm"
                color="red"
              />
              <AlertCard
                title="Cảnh Báo Trung Bình"
                count={5}
                description="Khu vực cần chú ý về an toàn thực phẩm"
                color="yellow"
              />
              <AlertCard title="An Toàn" count={12} description="Khu vực đảm bảo an toàn thực phẩm" color="green" />
            </div>
          </TabsContent>

          <TabsContent value="environment">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center">
                    <ThermometerSun className="mr-2 h-5 w-5 text-yellow-500" />
                    Nhiệt Độ & Độ Ẩm
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-4 bg-yellow-50 rounded-lg">
                      <p className="text-sm text-gray-500 mb-1">Nhiệt Độ</p>
                      <p className="text-3xl font-bold text-yellow-600">28°C</p>
                      <p className="text-xs text-gray-500">Cao hơn 2°C so với hôm qua</p>
                    </div>
                    <div className="text-center p-4 bg-blue-50 rounded-lg">
                      <p className="text-sm text-gray-500 mb-1">Độ Ẩm</p>
                      <p className="text-3xl font-bold text-blue-600">65%</p>
                      <p className="text-xs text-gray-500">Thấp hơn 5% so với hôm qua</p>
                    </div>
                  </div>
                  <div className="mt-4">
                    <p className="text-sm text-gray-600">
                      Nhiệt độ và độ ẩm hiện tại phù hợp cho việc bảo quản hầu hết các loại thực phẩm. Lưu ý giữ thực
                      phẩm dễ hỏng trong tủ lạnh.
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center">
                    <Wind className="mr-2 h-5 w-5 text-sky-500" />
                    Chất Lượng Không Khí & Bụi
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <p className="text-sm text-gray-500 mb-1">Chất Lượng Không Khí</p>
                      <p className="text-3xl font-bold text-green-600">Tốt</p>
                      <p className="text-xs text-gray-500">AQI: 45</p>
                    </div>
                    <div className="text-center p-4 bg-orange-50 rounded-lg">
                      <p className="text-sm text-gray-500 mb-1">Bụi</p>
                      <p className="text-3xl font-bold text-orange-600">Trung bình</p>
                      <p className="text-xs text-gray-500">PM2.5: 18 µg/m³</p>
                    </div>
                  </div>
                  <div className="mt-4">
                    <p className="text-sm text-gray-600">
                      Chất lượng không khí hiện tại ở mức tốt. Tuy nhiên, lượng bụi ở mức trung bình, nên rửa kỹ rau củ
                      quả trước khi sử dụng.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

function MapMarker({ color }: { color: "red" | "yellow" | "green" }) {
  const colorClasses = {
    red: "text-red-500 bg-red-100",
    yellow: "text-yellow-500 bg-yellow-100",
    green: "text-green-500 bg-green-100",
  }

  return (
    <div className={`p-1 rounded-full ${colorClasses[color]}`}>
      <MapPin className="h-6 w-6" />
    </div>
  )
}

function AlertCard({
  title,
  count,
  description,
  color,
}: {
  title: string
  count: number
  description: string
  color: "red" | "yellow" | "green"
}) {
  const colorClasses = {
    red: "bg-red-50 border-red-200",
    yellow: "bg-yellow-50 border-yellow-200",
    green: "bg-green-50 border-green-200",
  }

  const textColorClasses = {
    red: "text-red-600",
    yellow: "text-yellow-600",
    green: "text-green-600",
  }

  return (
    <div className={`p-4 rounded-lg border ${colorClasses[color]}`}>
      <div className="flex items-center justify-between mb-2">
        <h3 className={`font-medium ${textColorClasses[color]}`}>{title}</h3>
        {color !== "green" && <AlertTriangle className={`h-5 w-5 ${textColorClasses[color]}`} />}
      </div>
      <p className="text-2xl font-bold mb-1">{count}</p>
      <p className="text-sm text-gray-600">{description}</p>
    </div>
  )
}

