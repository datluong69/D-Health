import { Clover } from "lucide-react"

export default function Logo({ size = "default" }: { size?: "small" | "default" | "large" }) {
  const sizes = {
    small: {
      container: "h-8 w-8",
      icon: "h-5 w-5",
      text: "text-sm",
    },
    default: {
      container: "h-10 w-10",
      icon: "h-6 w-6",
      text: "text-xl",
    },
    large: {
      container: "h-14 w-14",
      icon: "h-8 w-8",
      text: "text-2xl",
    },
  }

  return (
    <div className="flex items-center space-x-2">
      <div className={`${sizes[size].container} rounded-full bg-green-100 flex items-center justify-center`}>
        <Clover className={`${sizes[size].icon} text-green-600`} />
      </div>
      <span className={`font-bold ${sizes[size].text} text-green-600`}>D Healthy Life</span>
    </div>
  )
}

